# AEGIS - Native Android Offline WebView Wrapper

This project packages the AEGIS offline survival and innovation AI guide as a standalone native Android APK.

## Folder Setup
Place all your AEGIS web files (HTML, CSS, JS, Assets) in:
`app/src/main/assets/www/`

Ensure your entry point is named `index.html` inside that directory.

## Exposed Native Bridge API (window.AegisAndroid)
- `window.AegisAndroid.toast(message)`
- `window.AegisAndroid.isOnline()` -> returns boolean
- `window.AegisAndroid.share(text, title)`
- `window.AegisAndroid.getAppVersion()` -> returns "1.0.0"
- `window.AegisAndroid.vibrate(durationMs)`

## Directory Structure
MyAegisApp/
├── app/
│   ├── build.gradle                   <-- Target SDK 34, Min SDK 24
│   └── src/
│       └── main/
│           ├── AndroidManifest.xml    <-- Permissions: VIBRATE, INTERNET, ACCESS_NETWORK_STATE
│           ├── java/com/aegis/offline/app/
│           │   └── MainActivity.java  <-- WebView + @JavascriptInterface AegisAndroid
│           ├── res/
│           │   ├── layout/
│           │   │   └── activity_main.xml
│           │   └── values/
│           │       └── themes.xml     <-- Fullscreen NoActionBar Theme
│           └── assets/                <-- [STANDALONE OFFLINE ASSETS]
│               └── www/               <-- 100% Offline Survival & Innovation Core
│                   ├── index.html     <-- Apocalyptic Landing Page & Hybrid Chatbot
│                   └── js/
│                       ├── aegis-kb.js     <-- Expanded Knowledge Base (10 Domains)
│                       ├── aegis-chat.js   <-- Hybrid AI Engine (Offline NLP + Online RAG)
│                       ├── app.js          <-- UI Controller & Search Logic
│                       └── aegis-bridge.js <-- JavascriptInterface Native Wrapper
├── build.gradle (Project)
└── settings.gradle
