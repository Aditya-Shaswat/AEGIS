/**
 * AEGIS Native Bridge JavaScript Wrapper
 * Seamlessly interfaces with Android @JavascriptInterface (AegisAndroid)
 */
const AegisBridge = {
  isNative: () => typeof window.AegisAndroid !== 'undefined',

  toast: (message) => {
    if (AegisBridge.isNative()) {
      window.AegisAndroid.toast(message);
    } else {
      console.log('[AEGIS Bridge Fallback: Toast]', message);
    }
  },

  isOnline: () => {
    if (AegisBridge.isNative()) {
      return window.AegisAndroid.isOnline();
    }
    return navigator.onLine;
  },

  share: (text, title = 'AEGIS Protocol') => {
    if (AegisBridge.isNative()) {
      window.AegisAndroid.share(text, title);
    } else if (navigator.share) {
      navigator.share({ title, text }).catch(() => {});
    } else {
      alert(`[AEGIS Share]\n${title}\n\n${text}`);
    }
  },

  getAppVersion: () => {
    if (AegisBridge.isNative()) {
      return window.AegisAndroid.getAppVersion();
    }
    return '1.0.0 (Web PWA)';
  },

  vibrate: (durationMs = 150) => {
    if (AegisBridge.isNative()) {
      window.AegisAndroid.vibrate(durationMs);
    } else if ('vibrate' in navigator) {
      navigator.vibrate(durationMs);
    }
  }
};

window.AegisBridge = AegisBridge;
