/**
 * AEGIS Main Application Controller
 */

document.addEventListener('DOMContentLoaded', () => {
  // Navigation Tabs
  const tabBtns = document.querySelectorAll('.tab-btn');
  const panels = {
    hero: document.getElementById('view-hero'),
    chat: document.getElementById('view-chat'),
    kb: document.getElementById('view-kb')
  };

  function switchTab(tabKey) {
    tabBtns.forEach(btn => {
      btn.classList.toggle('active', btn.dataset.tab === tabKey);
    });
    Object.keys(panels).forEach(key => {
      if (panels[key]) {
        panels[key].classList.toggle('active', key === tabKey);
      }
    });
    if (window.AegisBridge) {
      window.AegisBridge.vibrate(30);
    }
  }

  tabBtns.forEach(btn => {
    btn.addEventListener('click', () => switchTab(btn.dataset.tab));
  });

  // Hero CTAs
  document.getElementById('btn-hero-start')?.addEventListener('click', () => switchTab('chat'));
  document.getElementById('btn-hero-kb')?.addEventListener('click', () => switchTab('kb'));

  // Render Knowledge Domains on Landing Grid
  const landingGrid = document.getElementById('landing-domain-grid');
  const kbData = window.AEGIS_KB || [];

  const domainsMap = {};
  kbData.forEach(item => {
    domainsMap[item.domain] = (domainsMap[item.domain] || 0) + 1;
  });

  const domainIcons = {
    'Emergency Medical': '✚',
    'Core Survival': '◈',
    'Water Systems': '◉',
    'Food Production': '◐',
    'Engineering & Construction': '◧',
    'Energy Production': '⚡',
    'Materials & Manufacturing': '⚒',
    'Improvised Crafting': '⚒',
    'Emergency Preparedness': '🎒',
    'Communication Systems': '📡',
    'Civilization Recovery': '◑',
    'Security & Defense': '🛡'
  };

  if (landingGrid) {
    landingGrid.innerHTML = Object.keys(domainsMap).map(dom => `
      <div class="domain-card" data-domain="${dom}">
        <div class="domain-card-icon">${domainIcons[dom] || '◈'}</div>
        <div class="domain-card-name">${dom}</div>
        <div class="domain-card-count">${domainsMap[dom]} protocols</div>
      </div>
    `).join('');

    landingGrid.querySelectorAll('.domain-card').forEach(card => {
      card.addEventListener('click', () => {
        const dom = card.dataset.domain;
        filterByDomain(dom);
        switchTab('kb');
      });
    });
  }

  // Knowledge Base Explorer View
  const kbDomainPills = document.getElementById('kb-domain-pills');
  const kbArticleList = document.getElementById('kb-article-list');
  const kbSearchInput = document.getElementById('kb-search-input');
  let currentDomain = 'all';

  if (kbDomainPills) {
    const allDomains = ['all', ...Object.keys(domainsMap)];
    kbDomainPills.innerHTML = allDomains.map(d => `
      <button class="domain-pill-btn ${d === 'all' ? 'active' : ''}" data-domain="${d}">
        ${d === 'all' ? '◈ ALL' : (domainIcons[d] || '◈') + ' ' + d}
      </button>
    `).join('');

    kbDomainPills.querySelectorAll('.domain-pill-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        filterByDomain(btn.dataset.domain);
      });
    });
  }

  function filterByDomain(dom) {
    currentDomain = dom;
    if (kbDomainPills) {
      kbDomainPills.querySelectorAll('.domain-pill-btn').forEach(btn => {
        btn.classList.toggle('active', btn.dataset.domain === dom);
      });
    }
    renderArticles();
  }

  function renderArticles() {
    if (!kbArticleList) return;
    const q = (kbSearchInput?.value || '').toLowerCase().trim();

    const filtered = kbData.filter(item => {
      const matchDom = currentDomain === 'all' || item.domain === currentDomain;
      const matchSearch = !q || 
        item.title.toLowerCase().includes(q) ||
        item.tags.some(t => t.toLowerCase().includes(q)) ||
        item.content.toLowerCase().includes(q);
      return matchDom && matchSearch;
    });

    if (filtered.length === 0) {
      kbArticleList.innerHTML = `<div style="padding: 20px; text-align: center; color: var(--text-muted); font-family: var(--font-mono); font-size: 10px;">// NO MATCHING PROTOCOLS FOUND</div>`;
      return;
    }

    kbArticleList.innerHTML = filtered.map(art => {
      const badgeClass = art.critical_level === 'CRITICAL' ? 'badge-critical' : art.critical_level === 'HIGH' ? 'badge-high' : 'badge-normal';
      return `
        <div class="article-item" data-id="${art.id}">
          <div class="article-meta">
            <span style="color: var(--text-muted); text-transform: uppercase;">${art.domain}</span>
            <span class="${badgeClass}">${art.critical_level}</span>
          </div>
          <div class="article-item-title">${art.title}</div>
          <div class="article-item-tags">${art.tags.slice(0, 4).map(t => '#' + t).join(' ')}</div>
        </div>
      `;
    }).join('');

    kbArticleList.querySelectorAll('.article-item').forEach(item => {
      item.addEventListener('click', () => {
        const article = kbData.find(a => a.id === item.dataset.id);
        if (article) openArticleModal(article);
      });
    });
  }

  kbSearchInput?.addEventListener('input', renderArticles);
  renderArticles();

  // Modal Handling
  const articleModal = document.getElementById('article-modal');
  let currentModalArticle = null;

  function openArticleModal(article) {
    currentModalArticle = article;
    document.getElementById('modal-domain-tag').textContent = article.domain + ' // ' + article.critical_level;
    document.getElementById('modal-article-title').textContent = article.title;
    document.getElementById('modal-article-body').innerHTML = article.content;
    articleModal.classList.add('active');

    if (window.AegisBridge) {
      window.AegisBridge.vibrate(60);
      if (article.critical_level === 'CRITICAL') {
        window.AegisBridge.toast('🚨 Critical Protocol Loaded');
      }
    }
  }

  document.getElementById('btn-close-modal')?.addEventListener('click', () => {
    articleModal.classList.remove('active');
  });

  document.getElementById('btn-share-article')?.addEventListener('click', () => {
    if (currentModalArticle && window.AegisBridge) {
      window.AegisBridge.share(
        `AEGIS PROTOCOL: ${currentModalArticle.title}\nDomain: ${currentModalArticle.domain}\nPriority: ${currentModalArticle.critical_level}`,
        'AEGIS Field Intel'
      );
    }
  });

  document.getElementById('btn-bookmark-article')?.addEventListener('click', () => {
    if (window.AegisBridge) {
      window.AegisBridge.toast('Protocol saved to offline secure memory');
      window.AegisBridge.vibrate(80);
    }
  });

  // Settings Modal
  const settingsModal = document.getElementById('settings-modal');
  document.getElementById('btn-open-settings')?.addEventListener('click', () => {
    document.getElementById('setting-key-input').value = window.AegisChat?.getApiKey() || '';
    document.getElementById('setting-provider').value = window.AegisChat?.getProvider() || 'gemini';
    settingsModal.classList.add('active');
  });

  document.getElementById('btn-close-settings')?.addEventListener('click', () => {
    settingsModal.classList.remove('active');
  });

  document.getElementById('btn-save-settings')?.addEventListener('click', () => {
    const key = document.getElementById('setting-key-input').value;
    const provider = document.getElementById('setting-provider').value;
    window.AegisChat?.setApiKey(key, provider);
    settingsModal.classList.remove('active');
    if (window.AegisBridge) {
      window.AegisBridge.toast(key ? 'LLM RAG Mode Active' : 'Offline NLP Mode Active');
    }
  });

  // Chat Interface Handling
  const chatBox = document.getElementById('chat-box');
  const chatInput = document.getElementById('chat-input-field');
  const chatSendBtn = document.getElementById('chat-send-btn');

  async function handleSend(query) {
    const text = (query || chatInput?.value || '').trim();
    if (!text) return;
    if (chatInput) chatInput.value = '';

    // Append User Message
    const userMsgEl = document.createElement('div');
    userMsgEl.className = 'msg msg-user';
    userMsgEl.textContent = text;
    chatBox.appendChild(userMsgEl);
    chatBox.scrollTop = chatBox.scrollHeight;

    if (window.AegisBridge) {
      window.AegisBridge.vibrate(40);
    }

    // Append Bot Thinking Indicator
    const botMsgEl = document.createElement('div');
    botMsgEl.className = 'msg msg-bot';
    botMsgEl.innerHTML = `<span class="msg-badge">AEGIS ENGINE // QUERYING</span><p>Synthesizing tactical parameters...</p>`;
    chatBox.appendChild(botMsgEl);
    chatBox.scrollTop = chatBox.scrollHeight;

    try {
      const res = await window.AegisChat.query(text);
      let html = `<span class="msg-badge">${res.source}</span>`;
      if (res.errorNotice) {
        html += `<div class="protocol-alert warning">${res.errorNotice}</div>`;
      }
      
      const formattedText = res.text
        .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
        .replace(/\*(.*?)\*/g, '<em>$1</em>')
        .replace(/\n/g, '<br>');
      
      html += `<p>${formattedText}</p>`;

      if (res.citations && res.citations.length > 0) {
        html += `<div class="msg-citations">`;
        res.citations.forEach(cit => {
          html += `
            <button class="citation-btn" data-id="${cit.id}">
              <span>📖 ${cit.title}</span>
              <span style="font-size: 8px;">${cit.critical_level}</span>
            </button>
          `;
        });
        html += `</div>`;
      }

      botMsgEl.innerHTML = html;

      // Attach citation click handlers
      botMsgEl.querySelectorAll('.citation-btn').forEach(btn => {
        btn.addEventListener('click', () => {
          const article = kbData.find(a => a.id === btn.dataset.id);
          if (article) openArticleModal(article);
        });
      });

    } catch (err) {
      botMsgEl.innerHTML = `<div class="protocol-alert critical">ERROR: ${err.message}</div>`;
    }

    chatBox.scrollTop = chatBox.scrollHeight;
  }

  chatSendBtn?.addEventListener('click', () => handleSend());
  chatInput?.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') handleSend();
  });

  document.querySelectorAll('.quick-pill').forEach(pill => {
    pill.addEventListener('click', () => {
      handleSend(pill.dataset.query);
    });
  });

  // Haptic Button
  document.getElementById('btn-haptic')?.addEventListener('click', () => {
    if (window.AegisBridge) {
      window.AegisBridge.vibrate(150);
      window.AegisBridge.toast('Haptic Pulse Triggered');
    }
  });
});
