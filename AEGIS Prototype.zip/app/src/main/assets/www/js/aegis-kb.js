/**
 * AEGIS Knowledge Base Data Store (100% Offline)
 * Schema: { id, domain, title, content, tags, critical_level }
 */
window.AEGIS_KB = [
  {
    "id": "surv-crit-01",
    "domain": "Core Survival",
    "title": "Emergency Firecraft: Friction, Sparks, Solar & Wet Weather",
    "critical_level": "CRITICAL",
    "tags": [
      "fire",
      "make fire",
      "start fire",
      "build fire",
      "friction fire",
      "bow drill",
      "hand drill",
      "ferro rod",
      "flint and steel",
      "tinder",
      "kindling",
      "char cloth",
      "campfire",
      "spark",
      "ember",
      "survival fire",
      "feather stick"
    ],
    "content": "\n      <div class=\"protocol-alert critical\">\n        <strong>CRITICAL SURVIVAL PRIORITY:</strong> Fire provides warmth against lethal hypothermia, water purification, signaling, predator deterrence, and morale. Master the Fire Triangle (Heat, Oxygen, Fuel).\n      </div>\n\n      <h3>1. The 3 Tiers of Fuel (Prepare BEFORE striking a spark)</h3>\n      <ul>\n        <li><strong>Tinder (Bird's Nest):</strong> Bone-dry, hair-thin fibrous material that catches a tiny spark (cattail fluff, crushed inner cedar bark, dry grass, dried punk wood, char cloth, cotton balls with petroleum jelly). Form into a loose fist-sized nest.</li>\n        <li><strong>Kindling:</strong> Matchstick to pencil-thickness dry twigs. Gather <strong>two large hat-fulls</strong> before starting.</li>\n        <li><strong>Fuel Wood:</strong> Finger-thickness up to wrist-thickness dry branches. Break into 30cm lengths and stack nearby.</li>\n      </ul>\n\n      <h3>2. Method A: Ferrocerium Rod & Flint (Easiest & Most Reliable)</h3>\n      <ol>\n        <li>Place your tinder nest on a dry bark base on the ground to block soil moisture.</li>\n        <li>Rest the tip of the ferro rod directly inside the tinder bundle.</li>\n        <li>Hold the striker/knife spine at a <strong>45-degree angle</strong> against the rod.</li>\n        <li><strong>Pull the ROD backward</strong> while keeping the striker stationary — this prevents knocking over your tinder bundle.</li>\n        <li>Shower molten 3,000°C sparks directly into the core until an ember glows.</li>\n        <li>Gently blow with long, steady breaths until the tinder bursts into flames.</li>\n      </ol>\n\n      <h3>3. Method B: Bow Drill Friction Fire (Zero Equipment)</h3>\n      <ol>\n        <li><strong>Materials:</strong> Non-resinous medium-soft dead woods (Cedar, Willow, Aspen, Basswood, Poplar).</li>\n        <li><strong>Spindle & Hearth:</strong> Spindle is thumb-thick, 20cm long, carved round. Hearthboard is 1.5cm thick flat wood.</li>\n        <li><strong>The Notch:</strong> Burn a depression into the hearth with the spindle, then carve a <strong>60-degree V-notch</strong> cut from the edge inward, stopping just before the center of the depression. Place a dry leaf or bark slice under the notch to catch the ember dust.</li>\n        <li><strong>Drilling:</strong> Loop bowstring around spindle. Lubricate top bearing block with forehead skin oils or a green leaf. Apply firm downward pressure while drawing full, smooth bow strokes.</li>\n        <li>Speed up when thick white smoke billows. Continue for 10 more rapid strokes.</li>\n        <li>Carefully tap the glowing black carbon ember into your prepared tinder nest and blow gently into flame.</li>\n      </ol>\n\n      <h3>4. Method C: Solar / Optical Ignition</h3>\n      <p>Use a convex magnifying glass, eyeglass lens, bottom of a polished aluminum soda can (buffed with toothpaste/clay), or water-filled clear plastic bottle to focus direct sunlight into a pinpoint, intense focal dot onto charred cloth or dry dark fungus.</p>\n\n      <h3>5. Wet Weather Firecraft Tactics</h3>\n      <ul>\n        <li><strong>Dead Standing Wood:</strong> Never pick wood from the wet ground. Snap dry lower dead branches from standing pine or evergreen trees sheltered beneath the canopy.</li>\n        <li><strong>Feather Sticks:</strong> Shave thin curling wooden curls along a dry split branch using a knife without cutting all the way through. The thin curls catch flame instantly even in humid conditions.</li>\n        <li><strong>Birch Bark:</strong> Contains waterproof betulin oils that ignite and burn intensely even when soaking wet.</li>\n      </ul>\n    "
  },
  {
    "id": "surv-crit-02",
    "domain": "Core Survival",
    "title": "Emergency Wilderness Shelter: Debris Huts & Snow Caves",
    "critical_level": "CRITICAL",
    "tags": [
      "shelter",
      "debris hut",
      "lean to",
      "hypothermia",
      "insulation",
      "snow cave",
      "survival shelter",
      "cold weather",
      "bivy",
      "tarp"
    ],
    "content": "\n      <div class=\"protocol-alert critical\">\n        <strong>HYPOTHERMIA PREVENTION:</strong> You can die of hypothermia in less than 3 hours in cold, wet conditions. The earth leaches heat away through conduction 24x faster than air.\n      </div>\n\n      <h3>1. Shelter Site Selection (The 5 W's)</h3>\n      <ul>\n        <li><strong>Widowmakers:</strong> Check overhead for dead hanging branches or rotting trees that could collapse in wind.</li>\n        <li><strong>Wind:</strong> Build sheltered from prevailing gusts behind boulders, ridges, or dense thickets.</li>\n        <li><strong>Water:</strong> Stay minimum 30 meters away from streams (avoid flash floods and insect swarms) while keeping water accessible.</li>\n        <li><strong>Wood:</strong> Ensure abundant dry dead timber nearby for heating and frame building.</li>\n        <li><strong>Wildlife:</strong> Avoid game trails, animal burrows, and ant/wasp nests.</li>\n      </ul>\n\n      <h3>2. The Debris Hut (Solo Survival Cocoon)</h3>\n      <ol>\n        <li><strong>Ridgepole:</strong> Prop a sturdy 3-meter log on a sturdy tree stump or tripod fork at waist height (~1 meter).</li>\n        <li><strong>Ribbing:</strong> Lean sturdy branches along both sides of the ridgepole at a 45-degree angle, creating an A-frame skeleton just wide enough for your body.</li>\n        <li><strong>Lattice:</strong> Weave smaller branches across the ribs to prevent debris from falling inside.</li>\n        <li><strong>Insulation Bed:</strong> Pack the floor inside with <strong>0.5 meters (2 feet)</strong> of dry leaves, pine needles, or dry grass so your body never touches bare ground.</li>\n        <li><strong>Debris Covering:</strong> Pile dry leaves, pine needles, moss, and bark over the exterior until the debris layer is <strong>at least 1 meter (3 feet) thick</strong>. A 1-meter debris layer sheds rain and traps body heat even in sub-freezing temperatures.</li>\n      </ol>\n\n      <h3>3. Snow Cave (Sub-Zero Winter Survival)</h3>\n      <p>Dig horizontally into a deep snowdrift on the leeward side of a ridge. Form a raised sleeping platform higher than the entrance tunnel (so cold air drains down and pools out the doorway, trapping rising warm body heat at the bench). Poke a 5cm ventilation hole in the ceiling with a stick.</p>\n    "
  },
  {
    "id": "surv-high-01",
    "domain": "Core Survival",
    "title": "Natural Land Navigation: Sun, Stars, Shadows & Terrain",
    "critical_level": "HIGH",
    "tags": [
      "navigation",
      "compass",
      "shadow stick",
      "north star",
      "polaris",
      "lost in wilderness",
      "direction",
      "orienteering",
      "southern cross"
    ],
    "content": "\n      <h3>1. Shadow-Stick Method (True East-West Line)</h3>\n      <ol>\n        <li>Push a straight 1-meter stick vertically into level, unshaded ground.</li>\n        <li>Place a stone exactly at the tip of the stick's shadow (Point A).</li>\n        <li>Wait 15–20 minutes for the sun to move. Place a second stone at the new shadow tip (Point B).</li>\n        <li>Draw a straight line connecting Point A to Point B.</li>\n        <li><strong>Result:</strong> Point A is always <strong>WEST</strong> and Point B is always <strong>EAST</strong>. Stand with Point A on your left and Point B on your right — you are facing True North.</li>\n      </ol>\n\n      <h3>2. Celestial Navigation (Finding True North / South)</h3>\n      <ul>\n        <li><strong>Northern Hemisphere (Polaris / North Star):</strong> Locate the Big Dipper (Ursa Major). Find the two \"pointer stars\" forming the outer lip of the cup (Merak and Dubhe). Draw an imaginary straight line extending 5 times the distance between them to find Polaris, the North Star (accurate to within 1 degree of True North).</li>\n        <li><strong>Southern Hemisphere (Southern Cross):</strong> Locate the 4 stars of the Southern Cross. Extend the long axis 4.5 times toward the horizon to locate South.</li>\n      </ul>\n\n      <h3>3. Analog Watch Compass Method</h3>\n      <p>Point the hour hand directly at the Sun. In the Northern Hemisphere, the exact point halfway between the hour hand and the 12 o'clock mark is <strong>South</strong> (or North in the Southern Hemisphere).</p>\n    "
  },
  {
    "id": "surv-high-02",
    "domain": "Core Survival",
    "title": "Wilderness Foraging: Universal Edibility Test & Safe Plants",
    "critical_level": "HIGH",
    "tags": [
      "foraging",
      "edible plants",
      "universal edibility test",
      "poisonous",
      "berries",
      "mushrooms",
      "wild food",
      "hunger",
      "survival food"
    ],
    "content": "\n      <div class=\"protocol-alert critical\">\n        <strong>DANGER:</strong> Never eat wild mushrooms or unknown plants without positive botanical identification. Poisonous hemlock, death cap, and nightshades cause fatal organ failure.\n      </div>\n\n      <h3>1. The Universal Edibility Test (Takes 24 Hours)</h3>\n      <p>Test only ONE single plant part (leaf, root, stem, or seed) at a time on an empty stomach:</p>\n      <ol>\n        <li><strong>Smell Test:</strong> Crush the plant part. Reject immediately if it smells strongly of almonds/peach pits (cyanide) or rottenness.</li>\n        <li><strong>Skin Contact:</strong> Rub crushed sap on the soft inner forearm or wrist. Wait 15 minutes. If redness, itching, burning, or blisters occur, reject.</li>\n        <li><strong>Lip & Tongue Test:</strong> Touch plant to outer lip for 3 minutes. If no reaction, place on corner of tongue for 15 minutes. <strong>Do NOT swallow</strong>. If stinging, burning, numbness, or soapiness occurs, spit out and rinse.</li>\n        <li><strong>Small Ingestion:</strong> Chew a pea-sized piece thoroughly and swallow. Wait <strong>8 full hours</strong> without eating other foods. If nausea, stomach cramps, dizziness, or vomiting occurs, induce vomiting and drink copious clean water with activated charcoal.</li>\n        <li>If zero adverse symptoms after 8 hours, eat a 1/4-cup portion and wait another 8 hours before declaring safe.</li>\n      </ol>\n\n      <h3>2. Abundant Universal Survival Edibles</h3>\n      <ul>\n        <li><strong>Cattails (Typha):</strong> 100% edible year-round. Young spring shoots taste like cucumber; rhizome roots yield rich starch; pollen provides protein flour.</li>\n        <li><strong>Dandelions:</strong> Entire plant edible. Young leaves rich in vitamins A/C; roots roasted for tea.</li>\n        <li><strong>Pine Needle Tea:</strong> Steep fresh green pine needles (NOT yew) in hot water for massive Vitamin C doses (prevents scurvy).</li>\n        <li><strong>Acorns:</strong> Must be crushed and leached with multiple water flushes to wash out bitter astringent tannic acid before eating.</li>\n      </ul>\n    "
  },
  {
    "id": "surv-high-03",
    "domain": "Core Survival",
    "title": "Primitive Trapping: Figure-4 Deadfall & Fish Weirs",
    "critical_level": "HIGH",
    "tags": [
      "trapping",
      "hunting",
      "figure 4 deadfall",
      "snare",
      "fish trap",
      "weir",
      "primitive fishing",
      "protein",
      "game",
      "meat"
    ],
    "content": "\n      <h3>1. The Figure-4 Deadfall Trap</h3>\n      <p>An effective, non-metallic trigger mechanism for capturing small game (squirrels, rabbits, rodents) using gravity:</p>\n      <ul>\n        <li><strong>Components:</strong> 3 carved wooden sticks (Vertical Post, Diagonal Strut, Horizontal Bait Stick) + 1 Heavy Flat Deadfall Stone (10–15 kg).</li>\n        <li><strong>Notches:</strong>\n          <ul>\n            <li><em>Vertical Post:</em> Flat ground base, horizontal square notch on side, tapered chisel tip on top.</li>\n            <li><em>Diagonal Strut:</em> Top notch supports stone; center notch locks with vertical post; bottom notch mates with bait stick.</li>\n            <li><em>Bait Stick:</em> Carved notch mates with vertical post; point baited with insect, acorn, or fruit extending under center of stone.</li>\n          </ul>\n        </li>\n        <li><strong>Trigger Action:</strong> Animal touches bait &rarr; bait stick slips horizontally &rarr; diagonal strut collapses &rarr; stone drops instantly.</li>\n      </ul>\n\n      <h3>2. Primitive Stone Tidal & Stream Fish Weirs</h3>\n      <ol>\n        <li>Build a V-shaped or heart-shaped stone wall in a shallow river or tidal estuary pointing downstream.</li>\n        <li>Fish swim naturally into the wide funnel mouth and enter the enclosed inner chamber.</li>\n        <li>The narrow inward-pointing baffle makes it difficult for fish to find the exit hole, trapping them for collection at low tide or with hand nets/gigs.</li>\n      </ol>\n    "
  },
  {
    "id": "med-crit-01",
    "domain": "Emergency Medical",
    "title": "Severe Bleeding & Hemorrhage Control",
    "critical_level": "CRITICAL",
    "tags": [
      "tourniquet",
      "hemorrhage",
      "arterial",
      "trauma",
      "c-abcde",
      "wound",
      "bleeding",
      "blood"
    ],
    "content": "\n      <div class=\"protocol-alert critical\">\n        <strong>CRITICAL PRIORITY:</strong> Catastrophic arterial hemorrhage causes fatal exsanguination in under 90 seconds. Act immediately using the C-ABCDE protocol.\n      </div>\n      <h3>Immediate Interventions</h3>\n      <ol>\n        <li><strong>Direct Pressure:</strong> Apply relentless bilateral hand pressure directly over the wound site with sterile gauze or clean cloth. Do NOT release pressure to check wound.</li>\n        <li><strong>Wound Packing:</strong> For junctional areas (groin, axilla, base of neck), pack gauze aggressively into deep wound cavity until firm, then maintain continuous manual pressure for 3+ minutes.</li>\n        <li><strong>Tourniquet Application:</strong>\n          <ul>\n            <li>Place tourniquet <strong>5–7 cm (2–3 inches)</strong> proximal to wound (between injury and heart).</li>\n            <li><strong>NEVER</strong> apply directly over a joint (knee/elbow). If wound is adjacent to joint, position directly above joint.</li>\n            <li>Tighten windlass rod until bright arterial pulsing stops completely.</li>\n            <li>Lock rod into clip. Write exact application time on tourniquet and patient forehead (e.g. <code>T: 14:30</code>).</li>\n            <li>If bleeding persists, apply a 2nd tourniquet directly proximal (above) the 1st.</li>\n          </ul>\n        </li>\n      </ol>\n      <div class=\"note-box\">\n        <strong>Field Rule:</strong> Never loosen or remove a tourniquet in the field unless under qualified surgical care within 2 hours.\n      </div>\n    "
  },
  {
    "id": "med-crit-02",
    "domain": "Emergency Medical",
    "title": "Field CPR & Airway Resuscitation",
    "critical_level": "CRITICAL",
    "tags": [
      "cpr",
      "airway",
      "breathing",
      "resuscitation",
      "avpu",
      "chest compressions",
      "heart"
    ],
    "content": "\n      <div class=\"protocol-alert critical\">\n        <strong>CRITICAL PRIORITY:</strong> Irreversible brain damage begins within 3–4 minutes of cerebral hypoxia.\n      </div>\n      <h3>1. Rapid Assessment (AVPU Scale)</h3>\n      <ul>\n        <li><strong>A</strong> - Alert: Patient responds normally.</li>\n        <li><strong>V</strong> - Voice: Responds only to verbal commands.</li>\n        <li><strong>P</strong> - Pain: Responds only to sternal rub / trapezius squeeze.</li>\n        <li><strong>U</strong> - Unresponsive: Immediate emergency resuscitation required.</li>\n      </ul>\n      <h3>2. Airway Management</h3>\n      <ul>\n        <li><strong>Head-Tilt Chin-Lift:</strong> Place one hand on forehead, two fingers under bony chin, tilt back gently.</li>\n        <li><strong>Jaw Thrust:</strong> Mandatory if cervical spine / neck trauma is suspected. Push mandibular angles forward without extending neck.</li>\n        <li>Clear visible foreign obstructions from oral cavity using sweeping finger technique.</li>\n      </ul>\n      <h3>3. Resuscitation Cycle (30:2)</h3>\n      <ol>\n        <li>Position hands on center of chest (lower half of sternum).</li>\n        <li>Compress <strong>5–6 cm deep</strong> at a cadence of <strong>100–120 compressions/minute</strong>. Allow full recoil.</li>\n        <li>Deliver <strong>2 rescue breaths</strong> (1 second each, verifying chest rise).</li>\n        <li>Continue continuous 30:2 cycles until spontaneous breathing resumes or rescuer exhaustion.</li>\n        <li>Place responsive breathing unconscious patient into <em>Lateral Recovery Position</em> to prevent aspiration.</li>\n      </ol>\n    "
  },
  {
    "id": "med-crit-03",
    "domain": "Emergency Medical",
    "title": "Emergency Austere Childbirth",
    "critical_level": "CRITICAL",
    "tags": [
      "childbirth",
      "delivery",
      "obstetrics",
      "umbilical cord",
      "labor",
      "neonatal",
      "baby"
    ],
    "content": "\n      <div class=\"protocol-alert critical\">\n        <strong>EMERGENCY DELIVERY:</strong> Ensure thermal protection for neonate immediately upon delivery to prevent fatal hypothermia.\n      </div>\n      <h3>Delivery Procedure</h3>\n      <ol>\n        <li><strong>Preparation:</strong> Clean area with boiled water. Place clean cloth beneath mother. Prepare clean strings/shoelaces boiled for 10 min and clean sterile blade.</li>\n        <li><strong>Crowning & Delivery:</strong>\n          <ul>\n            <li>As head crowns, support perineum with clean cloth and apply gentle counter-pressure to head to prevent explosive delivery and tearing.</li>\n            <li>Check neck for umbilical cord (nuchal cord). If present, gently slip it over baby's head.</li>\n            <li>Support head as shoulders rotate (deliver top shoulder first with gentle downward guidance, then bottom shoulder upward).</li>\n          </ul>\n        </li>\n        <li><strong>Immediate Neonatal Care:</strong>\n          <ul>\n            <li>Dry infant vigorously with clean warm cloth to stimulate breathing. Keep baby lower than placenta until cord is clamped.</li>\n            <li>Place skin-to-skin directly on mother's bare chest and cover both with dry blankets.</li>\n          </ul>\n        </li>\n        <li><strong>Umbilical Cord Clamping:</strong> Wait 2–3 minutes for cord pulsation to stop. Tie string tightly <strong>5 cm (2 inches)</strong> from infant abdomen. Tie second string <strong>10 cm (4 inches)</strong> from abdomen. Cut between the two ties with sterilized blade.</li>\n        <li><strong>Placenta Delivery:</strong> Allow placenta to deliver naturally (10–30 min). <strong>NEVER pull on the cord</strong>. Save placenta to check completeness.</li>\n      </ol>\n    "
  },
  {
    "id": "med-high-01",
    "domain": "Emergency Medical",
    "title": "Wound Infection, Irrigation & Natural Antimicrobials",
    "critical_level": "HIGH",
    "tags": [
      "infection",
      "antimicrobials",
      "honey",
      "garlic",
      "irrigation",
      "cellulitis",
      "sepsis",
      "pus",
      "wounds"
    ],
    "content": "\n      <h3>1. Clinical Infection Stages</h3>\n      <ul>\n        <li><strong>Local:</strong> Erythema (redness), localized heat, swelling, purulent drainage (pus).</li>\n        <li><strong>Spreading (Cellulitis):</strong> Redness tracking proximally along lymph channels, expanding borders (mark border with pen).</li>\n        <li><strong>Systemic (Sepsis):</strong> Fever >38.3°C, tachycardia >90 bpm, tachypnea >20 bpm, altered mental state, hypotensive shock.</li>\n      </ul>\n      <h3>2. High-Pressure Irrigation</h3>\n      <p>The single most crucial step in preventing infection. Flush wound with 500–1000ml of clean potable water using a 20ml syringe with 18-gauge catheter (or plastic bag with pinhole). Never suture or close wounds older than <strong>6 hours</strong> or contaminated animal bites.</p>\n      <h3>3. Field-Tested Natural Antimicrobials</h3>\n      <ul>\n        <li><strong>Raw Honey:</strong> Produces enzymatic hydrogen peroxide and creates a high-osmotic, low-pH barrier inhospitable to bacteria (including MRSA). Apply generously and dress.</li>\n        <li><strong>Garlic (Allicin):</strong> Crush fresh garlic cloves and let stand for 10 minutes to activate allicin. Dilute with clean boiled water; potent against gram-positive and gram-negative bacteria.</li>\n        <li><strong>Turmeric (Curcumin):</strong> Powerful antiseptic and anti-inflammatory powder applied topically to minor lacerations.</li>\n      </ul>\n    "
  },
  {
    "id": "med-high-02",
    "domain": "Emergency Medical",
    "title": "Fracture Assessment & Improvised Splinting",
    "critical_level": "HIGH",
    "tags": [
      "fracture",
      "splint",
      "bone",
      "immobilization",
      "trauma",
      "pulse",
      "sprain"
    ],
    "content": "\n      <h3>1. Physical Assessment (CMS Checks)</h3>\n      <p>Always verify neurovascular integrity <strong>before and after</strong> splinting:</p>\n      <ul>\n        <li><strong>Circulation:</strong> Check distal pulse (radial/pedal) and capillary refill time (&lt; 2 seconds).</li>\n        <li><strong>Motor:</strong> Ask patient to wiggle fingers / toes.</li>\n        <li><strong>Sensory:</strong> Light touch on distal extremities; check for numbness or tingling.</li>\n      </ul>\n      <h3>2. Splinting Rules</h3>\n      <ol>\n        <li><strong>Immobilize Joint Above and Joint Below:</strong> For a forearm fracture, immobilize both the wrist and the elbow.</li>\n        <li><strong>Pad All Bony Prominences:</strong> Use cloth, moss, or foam between rigid struts (sticks, rolled magazines, trekking poles) and skin.</li>\n        <li><strong>Splint in Position Found:</strong> Only attempt gentle in-line traction if distal pulse is absent and limb is cold/cyanotic.</li>\n        <li>Secure splint with wide bandaging or paracord. Check CMS every 15 minutes to verify bandage is not cutting off circulation.</li>\n      </ol>\n    "
  },
  {
    "id": "water-crit-01",
    "domain": "Water Systems",
    "title": "Emergency Water Decontamination & Purification",
    "critical_level": "CRITICAL",
    "tags": [
      "boiling",
      "sodis",
      "bleach",
      "pathogens",
      "purification",
      "cholera",
      "chlorine",
      "drinking water"
    ],
    "content": "\n      <div class=\"protocol-alert critical\">\n        <strong>CRITICAL PRIORITY:</strong> Waterborne pathogens (Cholera, Giardia, Cryptosporidium, Dysentery) cause lethal dehydration. Never drink untreated surface water, seawater, or urine.\n      </div>\n      <h3>Primary Emergency Purification Methods</h3>\n      <ul>\n        <li><strong>Boiling (Gold Standard):</strong> Bring water to a vigorous rolling boil for at least <strong>1 full minute</strong> (3 minutes at elevations &gt; 2,000m / 6,500ft). Kills all protozoa, bacteria, and viruses.</li>\n        <li><strong>Chemical Disinfection (Unscented Household Bleach 5–8% Sodium Hypochlorite):</strong>\n          <ul>\n            <li>Clear water: Add <strong>2 drops per 1 litre</strong> (or 8 drops per gallon).</li>\n            <li>Cloudy / turbid water: Pre-filter through cloth, then add <strong>4 drops per litre</strong>.</li>\n            <li>Stir and let stand for <strong>30 minutes</strong>. Water should have a faint chlorine scent; if not, repeat dose and wait 15 minutes.</li>\n          </ul>\n        </li>\n        <li><strong>SODIS (Solar Water Disinfection):</strong> Fill clear PET plastic bottles (under 2L). Shake for 20 seconds to oxygenate. Lay horizontally in full direct sunlight on reflective surface (metal roof) for <strong>6 hours</strong> (or 2 consecutive days if 50% overcast). UV-A rays destroy pathogens.</li>\n      </ul>\n    "
  },
  {
    "id": "water-infra-01",
    "domain": "Water Systems",
    "title": "Groundwater Identification & Spring Development",
    "critical_level": "HIGH",
    "tags": [
      "groundwater",
      "spring",
      "water source",
      "vegetation",
      "alder",
      "willow",
      "cattail",
      "hydrology"
    ],
    "content": "\n      <h3>1. Identifying Groundwater Indicators</h3>\n      <ul>\n        <li><strong>Indicator Plants:</strong> Search for moisture-loving vegetation: <em>Willow, Cottonwood, Alder, Cattail, Reeds</em>. Roots indicate water table within 1–3 meters of surface.</li>\n        <li><strong>Topographic Formations:</strong> Converging valley bases, low hollows, foot of cliffs, and inside bends of dried river meanders.</li>\n        <li><strong>Warning:</strong> Water divining/dowsing rods are scientifically unverified; rely strictly on geological and botanical markers.</li>\n      </ul>\n      <h3>2. Natural Spring Development</h3>\n      <ol>\n        <li>Excavate <strong>0.5 meters</strong> into the hillside at the spring eye down to impermeable rock or clay layer.</li>\n        <li>Construct a collection box using flat stones bonded with clay or concrete.</li>\n        <li>Install a clean overflow pipe (PVC or bamboo) to discharge water smoothly without disturbing sediment.</li>\n        <li>Cover chamber with flat stone slab and seal edges with clay to block surface runoff.</li>\n        <li>Erect a protective fence at least <strong>30 meters upstream</strong> to exclude livestock and contamination.</li>\n      </ol>\n    "
  },
  {
    "id": "water-infra-02",
    "domain": "Water Systems",
    "title": "Emergency Sanitation: Latrines, VIP Vents & Tippy-Taps",
    "critical_level": "HIGH",
    "tags": [
      "sanitation",
      "latrine",
      "vip latrine",
      "tippy tap",
      "hygiene",
      "waste",
      "septic",
      "toilet"
    ],
    "content": "\n      <h3>1. Latrine Siting & Dimensions</h3>\n      <ul>\n        <li><strong>Distance Rule:</strong> Construct latrines minimum <strong>30 meters</strong> away from any water source and downhill from settlements.</li>\n        <li><strong>Standard Pit Latrine:</strong> Dig pit <strong>1m wide &times; 1m long &times; 2m deep</strong>. Line top 0.5m with wood or stone to prevent collapse.</li>\n        <li>Cover pit with a sturdy timber/concrete squat slab leaving a 20cm drop hole with a tight-fitting wooden lid.</li>\n      </ul>\n      <h3>2. VIP (Ventilated Improved Pit) Latrine</h3>\n      <p>Install an external black PVC or bamboo pipe (100–150mm diameter) from the pit extending 0.5m above roof level. Fit a corrosion-resistant fly screen mesh on top. Sunlight heats the pipe, creating a thermal chimney that sucks air down the drop hole, eliminating odor and trapping emerging flies.</p>\n      <h3>3. Tippy-Tap Field Handwashing Station</h3>\n      <p>Suspend a 5L plastic jug by its handle on a crossbar. Tie a string from jug neck to a foot pedal branch on the ground. Step on pedal to tip water for zero-touch handwashing. Suspend a bar of soap in a netted pouch alongside.</p>\n      <h3>4. Septic Tank Systems for Communities</h3>\n      <p>For groups &gt;20 people, build a dual-chamber sealed settling tank (2:1 size ratio). Anaerobic bacteria digest solids (sludge) while liquid effluent overflows into an underground gravel soakaway leach field.</p>\n    "
  },
  {
    "id": "water-tech-01",
    "domain": "Water Systems",
    "title": "Seep Wells & In-Bank Riverbed Extraction",
    "critical_level": "HIGH",
    "tags": [
      "seep well",
      "riverbank",
      "filtration",
      "turbid",
      "sediment",
      "well"
    ],
    "content": "\n      <h3>Seep Well Construction</h3>\n      <p>When river or stream water is thick with mud, algae, or industrial silt, do not drink directly. Use natural geological sand filtration:</p>\n      <ol>\n        <li>Walk <strong>2 to 5 meters</strong> back from the riverbank edge.</li>\n        <li>Dig a vertical hole <strong>0.5 to 2 meters deep</strong> until you reach the water table.</li>\n        <li>Line the pit walls with clean stones or woven willow wicker to prevent wall collapse.</li>\n        <li>Water seeping into the pit has filtered through meters of natural bank sand, removing 95%+ of turbidity, silt, and large organisms.</li>\n        <li>Bail out the first 2 muddy buckets, then allow clean, clarified seepage water to fill. Disinfect (boil/chlorinate) before drinking.</li>\n      </ol>\n    "
  },
  {
    "id": "water-tech-02",
    "domain": "Water Systems",
    "title": "Solar Desalination & Solar Condensation Stills",
    "critical_level": "HIGH",
    "tags": [
      "desalination",
      "solar still",
      "seawater",
      "distillation",
      "evaporation",
      "pure water"
    ],
    "content": "\n      <h3>1. Solar Basin Desalinator</h3>\n      <ul>\n        <li><strong>Components:</strong> A shallow black waterproof tray (holds saltwater/brackish water), covered with an airtight clear glass/plastic sheet angled at 15–20°.</li>\n        <li><strong>Operation:</strong> Solar radiation heats the black basin, evaporating pure water vapor. Vapor hits cooler glass cover, condenses into droplets, runs down into a collection V-trough.</li>\n        <li><strong>Yield:</strong> Produces <strong>1 to 3 Litres of pure distilled water per square meter</strong> per sunny day. Leaves heavy metals, salt, and pathogens behind.</li>\n      </ul>\n      <h3>2. Emergency Pit Solar Still</h3>\n      <p>Dig a 1m wide pit, 60cm deep. Place cup in center. Line pit perimeter with non-toxic green vegetation. Cover pit with clear plastic sheet, weigh down edges with soil. Place a central pebble over the cup to form a cone. Condensation drips into cup (yields 0.5–1.5L/day).</p>\n    "
  },
  {
    "id": "water-tech-03",
    "domain": "Water Systems",
    "title": "Ceramic Pot Filters & 3-Tier Gravity Towers",
    "critical_level": "HIGH",
    "tags": [
      "ceramic filter",
      "clay filter",
      "gravity tower",
      "activated charcoal",
      "sand filter",
      "pathogen filter"
    ],
    "content": "\n      <h3>1. Ceramic Pot Clay-Sawdust Filter</h3>\n      <ul>\n        <li><strong>Material Ratio:</strong> Mix <strong>50% dry powdered clay</strong> with <strong>50% fine sieved sawdust or rice husks</strong> by volume. Add water and knead into dough.</li>\n        <li><strong>Forming & Firing:</strong> Press into flowerpot shape. Fire in kiln or pit kiln to <strong>850°C–900°C</strong>.</li>\n        <li><strong>Mechanism:</strong> The sawdust burns away completely during firing, leaving a labyrinth of microscopic 0.6–3.0 micron tortuous pores that physically block 99% of bacteria, parasites, and protozoa while water slowly percolates through.</li>\n        <li>Flow rate: 1.5–3 Litres per hour per pot.</li>\n      </ul>\n      <h3>2. 3-Tier Gravity Filter Tower</h3>\n      <ol>\n        <li><strong>Top Container (Coarse):</strong> Perforated base. Layer 10cm washed river gravel (3-6mm) to catch leaves, bugs, and large silt.</li>\n        <li><strong>Middle Container (Fine & Chemical):</strong> Perforated base. Top layer: 20cm fine washed sand (0.2mm). Middle layer: 10cm crushed <em>Activated Charcoal</em> (removes organic toxins, odors, pesticides). Bottom layer: clean cloth mesh.</li>\n        <li><strong>Bottom Container (Clean Catch):</strong> Sealed reservoir with tap. Water is clarified and ready for boiling or UV disinfection.</li>\n      </ol>\n    "
  },
  {
    "id": "water-tech-04",
    "domain": "Water Systems",
    "title": "Sand Dams for Arid Seasonal Streams",
    "critical_level": "NORMAL",
    "tags": [
      "sand dam",
      "arid",
      "water storage",
      "evaporation",
      "aquifer",
      "concrete wall"
    ],
    "content": "\n      <h3>Sand Dam Engineering</h3>\n      <p>In seasonal drylands, building standard open water reservoirs fails due to massive evaporation (up to 2m/year) and mosquito breeding. A <strong>Sand Dam</strong> stores water inside coarse sand underground.</p>\n      <ul>\n        <li><strong>Construction:</strong> Build a reinforced concrete or stone masonry wall (1.5m–3m high) across a seasonal sand river valley anchored into bedrock.</li>\n        <li><strong>Sand Accumulation:</strong> Heavy monsoon rains wash coarse sand downriver, which settles behind the dam wall while fine silt floats over the spillway.</li>\n        <li><strong>Storage Capacity:</strong> Coarse sand holds <strong>25–40% water by volume</strong> in its pore space. Water is protected from sunlight (zero evaporation), parasites, and contamination.</li>\n        <li><strong>Extraction:</strong> Extract pristine cold water through a slotted perforated pipe embedded in the base gravel or a shallow hand-dug well upstream of the dam wall.</li>\n      </ul>\n    "
  },
  {
    "id": "eng-struct-01",
    "domain": "Engineering & Construction",
    "title": "Structural Principles: Timber Framing, Masonry & Arches",
    "critical_level": "HIGH",
    "tags": [
      "timber frame",
      "mortise and tenon",
      "masonry",
      "arches",
      "roof pitch",
      "triangles",
      "loads",
      "stone",
      "brick",
      "bricks",
      "construction",
      "building"
    ],
    "content": "\n      <h3>1. Universal Structural Principles</h3>\n      <ul>\n        <li><strong>Load Paths:</strong> Gravity and live loads must transfer continuously from roof &rarr; rafters &rarr; beams &rarr; posts/walls &rarr; foundation &rarr; solid bedrock/soil.</li>\n        <li><strong>Triangulation:</strong> Rectangles deform under lateral stress (racking); diagonal braces creating triangles provide absolute structural rigidity.</li>\n      </ul>\n      <h3>2. Timber Framing (Post-and-Beam)</h3>\n      <ul>\n        <li>Use <strong>mortise-and-tenon</strong> joinery secured with hardwood oak pegs (trenails) rather than nails, allowing wood to expand and contract with humidity without shearing.</li>\n        <li><strong>Roof Pitch:</strong> Minimum <strong>4:12 pitch</strong> (18.5° angle, ~33cm rise per 1m run) for corrugated metal/thatch to shed torrential rainfall efficiently; 8:12+ for heavy snow loads.</li>\n      </ul>\n      <h3>3. Stone Masonry & Arches</h3>\n      <ul>\n        <li><strong>Throughstones:</strong> Place long binder stones spanning the entire wall thickness every 1 meter to tie two stone faces together.</li>\n        <li><strong>True Arches & Vaults:</strong> Keystone at the apex transfers downward compressive forces laterally down the voussoirs into solid buttresses, spanning large gaps without tensile materials.</li>\n      </ul>\n    "
  },
  {
    "id": "eng-struct-02",
    "domain": "Engineering & Construction",
    "title": "Earth Construction: Adobe, Rammed Earth & Passive Solar",
    "critical_level": "HIGH",
    "tags": [
      "adobe",
      "adobe brick",
      "adobe bricks",
      "brick",
      "bricks",
      "mud brick",
      "rammed earth",
      "clay",
      "thermal mass",
      "passive solar",
      "stack effect",
      "building",
      "masonry",
      "cob"
    ],
    "content": "\n      <h3>1. Adobe Brick Formulation</h3>\n      <ul>\n        <li><strong>Soil Balance:</strong> <strong>25% to 50% Clay</strong> + <strong>50% to 75% Sand</strong> + <strong>10% Chopped Straw/Grass</strong> (tensile reinforcement).</li>\n        <li>Knead with water, pack into wooden block molds (e.g. 10 &times; 20 &times; 40 cm), dry in shade for 3 days, then cure in full sun for 3 weeks on edge.</li>\n      </ul>\n      <h3>2. Rammed Earth (Pisé)</h3>\n      <p>Erect sturdy parallel wooden formwork. Pour moist earth (8–10% moisture content) in <strong>15 cm lifts</strong>. Compact vigorously with a heavy hand tamper until volume compresses by 50% and rings like stone. Strip forms immediately and build next course.</p>\n      <h3>3. Passive Solar Architecture</h3>\n      <ul>\n        <li><strong>Orientation:</strong> Align long axis East-West; place main glazing facing True South (Northern Hemisphere) or True North (Southern Hemisphere).</li>\n        <li><strong>Thermal Mass:</strong> High-density adobe/stone interior floors and walls absorb excess solar heat by day and radiate it into the living space at night.</li>\n        <li><strong>Stack Effect Ventilation:</strong> Low air intakes on shady side + high clerestory exhaust vents create natural convection cooling without power.</li>\n      </ul>\n    "
  },
  {
    "id": "eng-struct-03",
    "domain": "Engineering & Construction",
    "title": "Disaster Resistance: Earthquakes, Hurricanes & Floods",
    "critical_level": "HIGH",
    "tags": [
      "earthquake",
      "hurricane",
      "flood",
      "ring beam",
      "tie downs",
      "levee",
      "resilience"
    ],
    "content": "\n      <h3>1. Seismic Resilience (Earthquakes)</h3>\n      <ul>\n        <li><strong>Continuous Ring Beam:</strong> Cast a continuous reinforced concrete or interlocking heavy timber bond beam around the top perimeter of all walls at roof level.</li>\n        <li><strong>Vertical Ties:</strong> Anchor corner rebar or high-tensile wire from foundation through masonry up to ring beam.</li>\n        <li>Keep building plans symmetrical (square or rectangle) to eliminate torsional twisting forces.</li>\n      </ul>\n      <h3>2. High-Wind & Cyclone Architecture</h3>\n      <ul>\n        <li><strong>Roof Geometry:</strong> 4-sided <strong>Hip Roofs (30° slope)</strong> perform vastly better in hurricane winds than vertical gable ends by deflecting wind pressure.</li>\n        <li><strong>Continuous Tie-Downs:</strong> Anchor roof rafters directly to ring beams and wall studs with metal hurricane strapping or wire lashing. Deep roof overhangs must be vented to prevent upward aerodynamic lift.</li>\n      </ul>\n      <h3>3. Flood Mitigation</h3>\n      <ul>\n        <li>Elevate ground floor living slabs minimum <strong>0.5 to 1.0 meter above historical 100-year flood lines</strong> using stone piers or timber stilts.</li>\n        <li>Construct earthen flood bunds (levees) upstream with a 3:1 side slope and clay core.</li>\n      </ul>\n    "
  },
  {
    "id": "eng-struct-04",
    "domain": "Engineering & Construction",
    "title": "Infrastructure: Roads, Culverts & Trestle Bridges",
    "critical_level": "NORMAL",
    "tags": [
      "roads",
      "culverts",
      "bridges",
      "infrastructure",
      "drainage",
      "gravel road"
    ],
    "content": "\n      <h3>1. Crowned Gravel Road Construction</h3>\n      <ul>\n        <li><strong>Crowning Profile:</strong> Road center must be <strong>4–6% higher</strong> than shoulders (convex curve) to shed surface water instantly into lateral ditches.</li>\n        <li>Maximum longitudinal gradient: <strong>10% slope</strong> to prevent wheel spinning and gravel scour.</li>\n        <li>Layering: 20cm coarse crushed rock base &rarr; 10cm compacted fine gravel/clay binder top layer.</li>\n      </ul>\n      <h3>2. Drainage Culverts</h3>\n      <p>Install stone or pipe culverts at every natural depression. Minimum culvert gradient: 2–3% to ensure self-cleaning velocity and prevent sediment siltation. Arm water inlets and outlets with stone rip-rap to eliminate erosion.</p>\n      <h3>3. Timber Trestle Bridges</h3>\n      <p>Drive 3–4 heavy timber piles per bent into riverbed rock/hardpan. Connect with horizontal cross-caps and diagonal X-bracing. Lay longitudinal stringers (sleepers) across bents and deck with 5cm hardwood planks.</p>\n    "
  },
  {
    "id": "energy-01",
    "domain": "Energy Production",
    "title": "Wood Energy: Rocket Stoves & Rocket Mass Heaters",
    "critical_level": "HIGH",
    "tags": [
      "rocket stove",
      "mass heater",
      "thermal mass",
      "wood stove",
      "efficient fire",
      "combustion"
    ],
    "content": "\n      <h3>1. Rocket Stove Principles</h3>\n      <p>Consumes <strong>75% less firewood</strong> than an open campfire while generating virtually zero smoke through complete secondary combustion.</p>\n      <ul>\n        <li><strong>Insulated Combustion Chamber:</strong> An L-shaped or J-shaped burn tunnel heavily insulated with perlite, pumice, or wood ash.</li>\n        <li><strong>Internal Draft Chimney (Heat Riser):</strong> Concentrates extreme temperatures (&gt;800°C), completely burning volatile wood gasses and soot.</li>\n        <li>Feed small-diameter sticks horizontally into bottom opening; gravity or draft draws flame inward.</li>\n      </ul>\n      <h3>2. Rocket Mass Heater (Space Heating)</h3>\n      <p>Enclose the heat riser inside a 200L metal drum. Route exhaust gases through 10–15 meters of horizontal metal stovepipe embedded inside a large <strong>cob/adobe thermal mass bench</strong> (seating area). The thermal mass absorbs 90% of exhaust heat before venting cool CO2 outside, releasing gentle radiant heat for 24–48 hours from a single 2-hour burn.</p>\n    "
  },
  {
    "id": "energy-02",
    "domain": "Energy Production",
    "title": "Charcoal Retort Kilns & Biomass Gasification",
    "critical_level": "HIGH",
    "tags": [
      "charcoal",
      "retort kiln",
      "pyrolysis",
      "gasification",
      "wood gas",
      "biofuel"
    ],
    "content": "\n      <h3>1. High-Yield Retort Charcoal Kiln</h3>\n      <ul>\n        <li><strong>Mechanism:</strong> Traditional dirt pit kilns burn 80% of wood to carbonize the rest (15–20% yield). A <strong>Retort Kiln</strong> places wood inside a sealed metal barrel heated externally from below.</li>\n        <li><strong>Syngas Recirculation:</strong> As wood heats to 400°C, it emits combustible wood gas (methane, hydrogen, carbon monoxide). Route this gas through bottom pipes back into the external firebox to fuel its own carbonization process.</li>\n        <li><strong>Yield:</strong> Achieves <strong>25% to 35% conversion yield</strong> of high-grade metallurgical charcoal.</li>\n      </ul>\n      <h3>2. Biomass Wood Gasification (Syngas for Engines)</h3>\n      <p>In a downdraft gasifier, restricted oxygen forces wood chips through a high-temperature constriction zone (1,000°C), cracking tars into flammable <em>Wood Gas (Carbon Monoxide + Hydrogen + Nitrogen)</em>. Run gas through a cyclonic ash filter, cooling radiator, and wood-chip filter directly into the carburetor of an internal combustion gasoline engine.</p>\n    "
  },
  {
    "id": "energy-03",
    "domain": "Energy Production",
    "title": "Mechanical Power: Waterwheels, Windmills & Treadles",
    "critical_level": "HIGH",
    "tags": [
      "waterwheel",
      "overshot",
      "windmill",
      "treadle",
      "mechanical power",
      "rpm",
      "generator"
    ],
    "content": "\n      <h3>1. Overshot Waterwheel Engineering</h3>\n      <ul>\n        <li>Water fed from an elevated flume into buckets on top of the wheel.</li>\n        <li><strong>Efficiency:</strong> <strong>70% to 85% mechanical efficiency</strong> (operates on pure weight of water rather than impulse velocity).</li>\n        <li><strong>Power Formula:</strong> Power (Watts) = $Q \times H \times g \times eta$ (where $Q$ is flow in kg/s, $H$ is head in meters, $g=9.81$, $eta=0.75$). A 3-meter diameter wheel with 150 L/s flow produces <strong>3.3 to 4.5 kW</strong> of continuous mechanical shaft power.</li>\n      </ul>\n      <h3>2. Wind Turbine Types</h3>\n      <ul>\n        <li><strong>Savonius Vertical Rotor:</strong> Made from halved 200L metal drums mounted on a vertical axle. Self-starting in any wind direction; high starting torque; ideal for low-speed mechanical water pumping.</li>\n        <li><strong>HAWT (Horizontal Axis Wind Turbine):</strong> 3 aerodynamic airfoil blades; high tip-speed ratio; best for electrical alternator generation.</li>\n      </ul>\n      <h3>3. Human Treadle Power</h3>\n      <p>A human legs-based bicycle treadle mechanism produces <strong>75–100 Watts of continuous power</strong> for 4+ hours (or 250W in short bursts) at 60–80 RPM, ideal for grain milling, lathe turning, or emergency battery charging.</p>\n    "
  },
  {
    "id": "energy-04",
    "domain": "Energy Production",
    "title": "Off-Grid Electrical: Alternators, Solar & Ohm’s Law",
    "critical_level": "HIGH",
    "tags": [
      "ohms law",
      "alternator",
      "solar",
      "electricity",
      "charge controller",
      "voltage",
      "current"
    ],
    "content": "\n      <h3>1. Fundamental Electrical Laws</h3>\n      <ul>\n        <li><strong>Ohm's Law:</strong> $V = I \times R$ (Voltage = Current &times; Resistance).</li>\n        <li><strong>Power Formula:</strong> $P = V \times I$ (Watts = Volts &times; Amperes). Current squared causes heat losses in cables: $P_{loss} = I^2 \times R$. Always keep wire runs short and thick.</li>\n      </ul>\n      <h3>2. Salvaged Automotive Alternator Conversion</h3>\n      <ul>\n        <li>Automotive alternators produce 12V DC (up to 60–100A) but require <strong>1,200 to 1,800 RPM</strong> minimum.</li>\n        <li><strong>Rotor Excitation:</strong> Standard alternators have an electromagnet rotor that needs an initial 12V current to start generating. Connect a small 12V 2W dashboard light bulb between battery positive and the 'D+' field terminal. Once spinning, the alternator self-excites.</li>\n        <li>For low-RPM waterwheels (30 RPM), use a 1:40 step-up belt/pulley transmission or convert rotor to NdFeB permanent magnets.</li>\n      </ul>\n      <h3>3. Solar Photovoltaic Setup</h3>\n      <p>Solar Panels &rarr; Charge Controller (MPPT preferred, PWM functional) &rarr; 12V/24V Deep Cycle Battery Bank &rarr; Pure Sine Wave Inverter (or direct 12V DC loads). Never connect panels directly to batteries without a regulator to avoid overcharging and boiling electrolyte.</p>\n    "
  },
  {
    "id": "energy-05",
    "domain": "Energy Production",
    "title": "Energy Storage: Lead-Acid, Daniell Cells & Mechanical",
    "critical_level": "NORMAL",
    "tags": [
      "batteries",
      "lead acid",
      "daniell cell",
      "earth battery",
      "flywheel",
      "pumped hydro",
      "storage"
    ],
    "content": "\n      <h3>1. Flooded Lead-Acid Battery Maintenance</h3>\n      <ul>\n        <li>Keep electrolyte level 1cm above lead plates. <strong>Top up ONLY with pure distilled/rain water</strong> (never tap water or acid).</li>\n        <li>State of Charge by resting voltage: <strong>12.7V = 100%</strong>, <strong>12.4V = 75%</strong>, <strong>12.0V = 50%</strong> (maximum safe discharge), <strong>10.5V = 0% (Fatal Damage)</strong>.</li>\n        <li>Perform monthly equalization charge at 15.0V to reverse plate sulfation.</li>\n      </ul>\n      <h3>2. Primitive Chemical Cells</h3>\n      <ul>\n        <li><strong>Daniell Cell:</strong> Copper electrode in Copper Sulfate ($CuSO_4$) solution + Zinc electrode in Zinc Sulfate ($ZnSO_4$) solution separated by a porous clay barrier. Generates steady 1.1 Volts.</li>\n        <li><strong>Earth Battery:</strong> Copper and Galvanized Steel plates buried 1 meter deep in moist, saline soil 5 meters apart. Generates 0.5–1.0V continuous trickle current for low-power LED/Morse telegraph circuits.</li>\n      </ul>\n      <h3>3. Mechanical Energy Storage</h3>\n      <p><strong>Pumped Hydro:</strong> Pump water uphill to an elevated pond when surplus power is available; run water down through a turbine when power is required (70% round-trip efficiency). <strong>Flywheels:</strong> Heavy stone or concrete disk spinning on greased bearings stores kinetic energy for short power bursts.</p>\n    "
  },
  {
    "id": "mat-01",
    "domain": "Materials & Manufacturing",
    "title": "Iron Smelting: Bloomery Furnace & Bog Iron",
    "critical_level": "HIGH",
    "tags": [
      "iron smelting",
      "bloomery",
      "bog iron",
      "hematite",
      "charcoal",
      "forge",
      "wrought iron"
    ],
    "content": "\n      <h3>1. Sourcing Iron Ore</h3>\n      <ul>\n        <li><strong>Bog Iron:</strong> Reddish-brown spongy nodules found in peat bogs and stagnant stream beds where iron-oxidizing bacteria precipitate dissolved iron.</li>\n        <li><strong>Magnetite / Hematite:</strong> Dense black or reddish rust-colored rocks; test with a compass or magnet.</li>\n      </ul>\n      <h3>2. Bloomery Furnace Operation</h3>\n      <ol>\n        <li>Build a 1.5m tall clay and sand cylindrical stack with 30cm internal bore. Insert clay tuyère pipe 15cm from base.</li>\n        <li>Pre-heat stack with wood. Once glowing, add alternating layers of <strong>hardwood charcoal</strong> and <strong>crushed roasted iron ore</strong> (1:1 by weight).</li>\n        <li>Pump dual leather bellows continuously to sustain <strong>1,100°C–1,200°C</strong> inside the stack.</li>\n        <li>Carbon monoxide reduces iron oxide solid to metallic iron without fully liquefying the iron. Molten silicate slag drains through the bottom tap hole.</li>\n        <li>After 6–8 hours, tear down front clay wall, extract glowing white-hot spongy <strong>Iron Bloom</strong> with heavy tongs.</li>\n        <li>Immediately hammer vigorously on an anvil stone to expel trapped slag and weld particles into solid wrought iron billet.</li>\n      </ol>\n    "
  },
  {
    "id": "mat-02",
    "domain": "Materials & Manufacturing",
    "title": "Steel Metallurgy: Hardening, Quenching & Tempering",
    "critical_level": "HIGH",
    "tags": [
      "steel",
      "hardening",
      "quenching",
      "tempering",
      "heat treatment",
      "metallurgy",
      "carbon steel"
    ],
    "content": "\n      <h3>1. Adding Carbon to Iron (Carburization)</h3>\n      <p>Wrought iron is too soft for cutting edges. Seal wrought iron bars inside a clay box packed with bone meal and crushed charcoal. Heat at 900°C for 8 hours (Blister Steel).</p>\n      <h3>2. Heat Treatment Sequence</h3>\n      <ol>\n        <li><strong>Hardening:</strong> Heat high-carbon steel to bright cherry red (<strong>~800°C</strong>, check with a magnet: steel loses magnetism at the Curie point 770°C). Plunge vertically into brine or vegetable oil to quench. Steel is now maximum hardness but glass-brittle.</li>\n        <li><strong>Tempering (Crucial Step):</strong> Polish quenched steel with sandpaper to bright silver. Heat gently over coals and watch oxide colors migrate:\n          <ul>\n            <li><em>Pale Straw (220°C):</em> Razors, scalpels, scribers.</li>\n            <li><em>Deep Straw (240°C):</em> Knives, wood chisels, drills.</li>\n            <li><em>Purple (275°C):</em> Axes, machetes, cold chisels.</li>\n            <li><em>Spring Blue (300°C):</em> Swords, springs, crowbars.</li>\n          </ul>\n          Quench immediately in water when desired temper color covers the cutting edge.\n        </li>\n      </ol>\n    "
  },
  {
    "id": "mat-03",
    "domain": "Materials & Manufacturing",
    "title": "Blacksmithing: Anvils, Forges & Core Techniques",
    "critical_level": "HIGH",
    "tags": [
      "blacksmithing",
      "anvil",
      "forge",
      "hammer",
      "tongs",
      "drawing out",
      "upsetting"
    ],
    "content": "\n      <h3>1. Fundamental Toolset</h3>\n      <ul>\n        <li><strong>The Forge:</strong> Firepot lined with fireclay, equipped with a bottom tuyère pipe and hand-cranked blower or bellows.</li>\n        <li><strong>The Anvil:</strong> Hardened steel face, horn (for curved bends), step (cutting plate), pritchel hole (punching holes), hardy hole (holding tooling).</li>\n        <li><strong>Tongs:</strong> Wolf-jaw, V-bit, and flat tongs to grip hot stock securely.</li>\n      </ul>\n      <h3>2. Core Blacksmithing Operations</h3>\n      <ul>\n        <li><strong>Drawing Out:</strong> Hammering hot stock on anvil face or horn to increase length and decrease thickness.</li>\n        <li><strong>Upsetting:</strong> Striking the end of a bar to thicken its cross-section.</li>\n        <li><strong>Bending:</strong> Working over anvil horn or over the hardy hole.</li>\n        <li><strong>Punching & Drifting:</strong> Driving a tapered steel punch through hot metal over the pritchel hole without removing core material.</li>\n        <li><strong>Forge Welding:</strong> Heat two pieces to sweating white heat (1,250°C), apply borax or clean silica sand as flux, deliver rapid overlapping hammer blows.</li>\n      </ul>\n    "
  },
  {
    "id": "mat-04",
    "domain": "Materials & Manufacturing",
    "title": "Bronze Casting, Ceramics, Glass & Optical Lenses",
    "critical_level": "NORMAL",
    "tags": [
      "bronze",
      "copper",
      "tin",
      "ceramics",
      "pottery",
      "kiln",
      "pit firing",
      "glass",
      "lens",
      "casting",
      "clay"
    ],
    "content": "\n      <h3>1. Bronze Metallurgy (The First Alloy)</h3>\n      <ul>\n        <li><strong>Composition:</strong> <strong>88–90% Copper + 10–12% Tin</strong>. Melts at <strong>950°C</strong> (much lower than pure copper 1,085°C or iron 1,538°C).</li>\n        <li>Molten bronze expands slightly upon cooling, perfectly capturing fine mold details in lost-wax (cire perdue) or sand casting molds. Resists saltwater corrosion.</li>\n      </ul>\n      <h3>2. Ceramics: Pit Firing vs High-Temperature Kiln</h3>\n      <ul>\n        <li><strong>Pit Firing (600°C–900°C):</strong> Unglazed earthenware, porous, requires fat/wax burnishing to hold liquids.</li>\n        <li><strong>Draft Kiln (1,000°C–1,300°C):</strong> Vitrifies clay into dense non-porous stoneware and porcelain with silica-ash glazes.</li>\n      </ul>\n      <h3>3. Glassmaking & Precision Optical Lenses</h3>\n      <ul>\n        <li><strong>Glass Batch:</strong> 70% Silica sand ($SiO_2$) + 15% Soda Ash ($Na_2CO_3$, leached from kelp/ash) + 10% Limestone ($CaCO_3$). Melts at 1,200°C into transparent glass.</li>\n        <li><strong>Grinding Convex Lenses:</strong> Rub two thick glass discs together with carborundum / fine emery grit and water in a figure-8 motion. Fine polish with cerium oxide / jewelers rouge on pitch. Yields magnifying lenses for fire ignition, reading, microscopes, and refractor telescopes.</li>\n      </ul>\n    "
  },
  {
    "id": "mat-05",
    "domain": "Materials & Manufacturing",
    "title": "Woodworking, Textile Looms & Natural Botanical Dyes",
    "critical_level": "NORMAL",
    "tags": [
      "woodworking",
      "dovetail",
      "textiles",
      "spinning",
      "loom",
      "natural dyes",
      "madder",
      "woad"
    ],
    "content": "\n      <h3>1. Wood Seasoning & Joinery</h3>\n      <ul>\n        <li><strong>Green vs Dry Wood:</strong> Green wood splits as it dries (5–10% tangential shrinkage). Season hardwood in a dry, ventilated shed for 1 year per 25mm thickness.</li>\n        <li><strong>Joints:</strong> Mortise-and-tenon for frame structures; dovetail joints for drawers and cabinetry (mechanical wedge interlock resists pull-out).</li>\n      </ul>\n      <h3>2. Textile Processing: Spindles & Looms</h3>\n      <ul>\n        <li><strong>Drop Spindle:</strong> Weighted whorl twirls carded wool, flax, or cotton fibers into strong, continuous yarn via twist friction.</li>\n        <li><strong>Looms:</strong> Rigid heddle and backstrap looms interweave warp (lengthwise under tension) and weft (crosswise shuttle) into sturdy canvas and apparel cloth.</li>\n      </ul>\n      <h3>3. Botanical Dye Formulation</h3>\n      <ul>\n        <li><strong>Weld (Reseda luteola):</strong> Bright brilliant yellow (flavonoids).</li>\n        <li><strong>Woad (Isatis tinctoria) / Indigo:</strong> Rich light-fast blue (requires anaerobic reduction vat).</li>\n        <li><strong>Madder Root (Rubia tinctorum):</strong> Deep crimson red (alizarin).</li>\n        <li><strong>Mordant:</strong> Soak fabric in Alum (Potassium aluminum sulfate) or iron water to chemically bind dye molecules permanently to protein/cellulose fibers.</li>\n      </ul>\n    "
  },
  {
    "id": "comms-01",
    "domain": "Communication Systems",
    "title": "Visual Distress Signaling: Smoke, Heliographs, Semaphore & Morse",
    "critical_level": "HIGH",
    "tags": [
      "signaling",
      "semaphore",
      "smoke signals",
      "heliograph",
      "morse code",
      "distress signal",
      "sos",
      "flags",
      "optical signaling"
    ],
    "content": "\n      <h3>1. Pre-Radio Long-Distance Signaling</h3>\n      <ul>\n        <li><strong>Smoke Distress Signals:</strong> 3 smoke pillars in a triangle or straight line (international distress). Wet leafy boughs generate dense white smoke against dark forests; rubber, engine oil, or damp pitch generate heavy black smoke against bright overcast skies.</li>\n        <li><strong>Heliograph (Signal Mirror):</strong> Flash sunlight off a pocket mirror or polished metal. Flash in series of 3s; visible up to <strong>30–50 km</strong> to passing rescue aircraft or mountain observation lookouts.</li>\n        <li><strong>Semaphore Flags:</strong> Two square flags (red/yellow) held at 8 distinct angular clock positions. Communicates letters over <strong>10–15 km line-of-sight</strong> between mountain lookouts with optical telescopes.</li>\n      </ul>\n      <h3>2. International Morse Code Table</h3>\n      <table class=\"data-table font-mono text-xs\">\n        <tr><td>A: • ─</td><td>B: ─ • • •</td><td>C: ─ • ─ •</td><td>D: ─ • •</td></tr>\n        <tr><td>E: •</td><td>F: • • ─ •</td><td>G: ─ ─ •</td><td>H: • • • •</td></tr>\n        <tr><td>I: • •</td><td>J: • ─ ─ ─</td><td>K: ─ • ─</td><td>L: • ─ • •</td></tr>\n        <tr><td>M: ─ ─</td><td>N: ─ •</td><td>O: ─ ─ ─</td><td>P: • ─ ─ •</td></tr>\n        <tr><td>Q: ─ ─ • ─</td><td>R: • ─ •</td><td>S: • • •</td><td>T: ─</td></tr>\n        <tr><td>U: • • ─</td><td>V: • • • ─</td><td>W: • ─ ─</td><td>X: ─ • • ─</td></tr>\n        <tr><td>Y: ─ • ─ ─</td><td>Z: ─ ─ • •</td><td colspan=\"2\"><strong>SOS: ••• ─── •••</strong></td></tr>\n      </table>\n    "
  },
  {
    "id": "comms-02",
    "domain": "Communication Systems",
    "title": "Information Storage: Papermaking & Movable Type",
    "critical_level": "NORMAL",
    "tags": [
      "paper",
      "papermaking",
      "printing press",
      "movable type",
      "ink",
      "knowledge preservation"
    ],
    "content": "\n      <h3>1. Hand Papermaking from Plant Fibers</h3>\n      <ol>\n        <li>Harvest plant fibers (cotton rags, hemp, flax, mulberry bark). Boil in 2% lye (wood ash water) for 4 hours to dissolve lignin.</li>\n        <li>Macerate and pound fibers into fine pulp slurry in a vat with clean water.</li>\n        <li>Dip a rectangular wire/fabric mesh screen (deckle and mold) into slurry, lift horizontally, shake gently to interlock fibers.</li>\n        <li>Couch onto damp felt, stack multiple sheets, press in a heavy screw press to expel 80% water. Hang dry.</li>\n      </ol>\n      <h3>2. Movable Type Printing Press</h3>\n      <p>Cast reusable individual lead-tin-antimony alloy type characters. Compose text mirrored in a wooden composing stick, lock into a chase (forme). Ink with lampblack + boiled linseed oil ink. Roll under a heavy screw platen onto damp paper (prints 250+ identical pages per hour).</p>\n    "
  },
  {
    "id": "comms-03",
    "domain": "Communication Systems",
    "title": "Primitive Radio: Crystal Receivers & Spark Transmitters",
    "critical_level": "HIGH",
    "tags": [
      "crystal radio",
      "spark gap",
      "radio receiver",
      "am radio",
      "galena",
      "diode",
      "antenna"
    ],
    "content": "\n      <h3>1. Zero-Power Crystal AM Radio Receiver</h3>\n      <p>Operates entirely on the electro-magnetic energy captured by the antenna—no battery required.</p>\n      <ul>\n        <li><strong>Antenna:</strong> 20–30 meters of copper wire strung high outdoors, insulated from trees.</li>\n        <li><strong>Earth Ground:</strong> Heavy copper wire clamped to a metal water pipe or 2m copper rod hammered into damp earth.</li>\n        <li><strong>Tuning Coil:</strong> 100 turns of enameled magnet wire wrapped tightly around a 5cm cardboard/PVC tube with an insulation-scraped slider bar.</li>\n        <li><strong>Detector Diode:</strong> Germanium diode (1N34A) or a natural <em>Galena crystal ($PbS$) touched lightly with a fine phosphor-bronze wire (\"Cat's Whisker\")</em>. Rectifies high-frequency RF to audible audio.</li>\n        <li><strong>Earphone:</strong> High-impedance (2,000 Ohm) piezoelectric crystal earpiece.</li>\n      </ul>\n      <h3>2. Spark Gap Morse Transmitter</h3>\n      <p>Battery &rarr; Telegraph Key &rarr; Automotive Ignition Coil &rarr; 1mm Spark Gap connected across antenna and ground. Rapid electrical discharges generate broad damped electromagnetic waves receivable for miles on any crystal set.</p>\n    "
  },
  {
    "id": "comms-04",
    "domain": "Communication Systems",
    "title": "Amateur Radio: HF Ionospheric Bands & Dipole Antennas",
    "critical_level": "HIGH",
    "tags": [
      "amateur radio",
      "ham radio",
      "dipole",
      "hf",
      "vhf",
      "frequencies",
      "ionosphere"
    ],
    "content": "\n      <h3>1. Propagation & Band Characteristics</h3>\n      <ul>\n        <li><strong>HF (High Frequency, 3–30 MHz):</strong> Bounces off the ionosphere (F-layer), enabling global intercontinental communications with low power (10–100W). Best night bands: 80m (3.5 MHz), 40m (7 MHz). Best day bands: 20m (14 MHz), 15m (21 MHz).</li>\n        <li><strong>VHF (Very High Frequency, 30–300 MHz):</strong> Strict line-of-sight local communications (5–50 km). 2-meter band (144–148 MHz) is the universal tactical standard.</li>\n      </ul>\n      <h3>2. Half-Wave Dipole Antenna Formula</h3>\n      <p>The most reliable, high-efficiency antenna. Length formula:</p>\n      <div class=\"code-block font-mono\">\n        Total Length (meters) = 142.6 / Frequency (MHz)\n      </div>\n      <p>For 7.1 MHz (40m emergency band): $142.6 / 7.1 = 20.08$ meters total (two 10.04m wire elements separated by a center insulator and fed with 50-Ohm coax).</p>\n    "
  },
  {
    "id": "civ-gov-01",
    "domain": "Civilization Recovery",
    "title": "Crisis Governance: Emergency Command to Councils",
    "critical_level": "HIGH",
    "tags": [
      "governance",
      "leadership",
      "transitional council",
      "rationing",
      "charter",
      "rule of law"
    ],
    "content": "\n      <h3>1. Phased Leadership Evolution</h3>\n      <ul>\n        <li><strong>Phase 1: Emergency Command (Days 1–30):</strong> Singular tactical command-and-control hierarchy focused exclusively on immediate survival, trauma triage, defense, and potable water securing.</li>\n        <li><strong>Phase 2: Transitional Council (Month 2+):</strong> Form a 5–7 member council with rotating departmental directors (Defense, Agriculture, Medical, Engineering, Logistics, Justice).</li>\n      </ul>\n      <h3>2. Rationing & Resource Distribution</h3>\n      <ul>\n        <li><strong>Equal Base Sustenance:</strong> Every community member receives a baseline caloric survival ration (1,800 kcal/day + 3L clean water).</li>\n        <li><strong>Labor Productivity Supplement:</strong> Heavy physical laborers (farmers, quarrymen, builders, perimeter guards) receive additional caloric allocations (500–1,000 kcal).</li>\n      </ul>\n      <h3>3. Rule of Law & Written Charters</h3>\n      <p>Prevent warlordism by immediately drafting and publicly posting a community charter defining property rights, dispute arbitration, guard shift duty quotas, and fair restitution protocols.</p>\n    "
  },
  {
    "id": "civ-gov-02",
    "domain": "Civilization Recovery",
    "title": "Education, Literacy & Apprenticeship Guilds",
    "critical_level": "NORMAL",
    "tags": [
      "education",
      "literacy",
      "phonics",
      "apprenticeship",
      "skills registry",
      "library"
    ],
    "content": "\n      <h3>1. Systematic Phonics Literacy</h3>\n      <p>Preserve written communication across generations using synthetic phonics: teach the 44 basic phoneme sounds of English and letter grapheme pairings before whole-word memorization.</p>\n      <h3>2. Structured Master-Apprentice Guilds</h3>\n      <ul>\n        <li>Pair experienced specialists (blacksmiths, herbalists, mechanics, carpenters) with 2 youth apprentices.</li>\n        <li>Three tiers: <em>Apprentice</em> (observes and performs manual prep) &rarr; <em>Journeyman</em> (executes standard work independently) &rarr; <em>Master</em> (innovates, designs, and trains).</li>\n      </ul>\n      <h3>3. Community Skills Registry & Central Library</h3>\n      <p>Catalog all technical books, repair manuals, medical texts, and map atlases in a secure, weather-proof vault. Maintain an active registry of all citizens' verified practical trade competencies.</p>\n    "
  },
  {
    "id": "civ-sci-01",
    "domain": "Civilization Recovery",
    "title": "Scientific Method & Foundational Physical Sciences",
    "critical_level": "NORMAL",
    "tags": [
      "science",
      "scientific method",
      "germ theory",
      "chemistry",
      "arithmetic",
      "physics"
    ],
    "content": "\n      <h3>1. The Scientific Method Protocol</h3>\n      <ol>\n        <li><strong>Observation:</strong> Document physical phenomena without bias.</li>\n        <li><strong>Falsifiable Hypothesis:</strong> Propose a specific, testable cause-and-effect relationship.</li>\n        <li><strong>Controlled Experiment:</strong> Test changing only ONE variable while holding all others constant.</li>\n        <li><strong>Replication & Peer Verification:</strong> Independent verification by others before accepting as scientific fact.</li>\n      </ol>\n      <h3>2. Non-Negotiable Foundational Knowledge</h3>\n      <ul>\n        <li><strong>Germ Theory of Disease:</strong> Microscopic pathogens cause infections; boiling water and hand hygiene interrupt transmission vectors.</li>\n        <li><strong>Acid-Base Chemistry:</strong> pH scale (0–14). Acids (vinegar, sulfuric acid) react with bases (wood ash lye, lime) to form neutral salts and water.</li>\n        <li><strong>Laws of Thermodynamics:</strong> Energy is neither created nor destroyed, only transformed; heat always flows from hotter to cooler bodies.</li>\n      </ul>\n    "
  },
  {
    "id": "civ-trans-01",
    "domain": "Civilization Recovery",
    "title": "Post-Industrial Transport: Draft Animals, Carts & Sails",
    "critical_level": "NORMAL",
    "tags": [
      "transportation",
      "horse collar",
      "wagons",
      "bicycles",
      "boats",
      "sails",
      "draft animal"
    ],
    "content": "\n      <h3>1. Animal Traction: The Padded Horse Collar</h3>\n      <ul>\n        <li>Ancient throat harnesses choked horses when pulling heavy loads. A <strong>rigid, padded horse collar</strong> transfers traction directly to the animal's skeletal shoulders and chest, increasing pulling power by <strong>400%–500%</strong> (up to 1,500 kg per horse).</li>\n        <li>Use wooden yokes for oxen pairs attached to horn bases or withers.</li>\n      </ul>\n      <h3>2. Wheeled Vehicles & Bicycles</h3>\n      <ul>\n        <li>Wagons must feature a <strong>pivoting front axle</strong> with a fifth-wheel plate to allow tight turning radii without tipping.</li>\n        <li>Bicycles are the most energetically efficient human transportation ever engineered (4x more efficient than walking per calorie consumed). Maintain inner tube patch kits and chain lubricants.</li>\n      </ul>\n      <h3>3. Maritime Transport & Lateen Sails</h3>\n      <p>Dugout canoes and clinker-built wooden planks with pitch caulking. Triangular <strong>Lateen Sails</strong> allow boats to sail \"tack\" into the wind (at 45° angles), liberating nautical travel from fixed trade wind directions.</p>\n    "
  },
  {
    "id": "food-adv-01",
    "domain": "Food Production",
    "title": "Hydroponics: Deep Water Culture & Improvised Nutrients",
    "critical_level": "HIGH",
    "tags": [
      "hydroponics",
      "dwc",
      "nutrients",
      "wood ash",
      "bone meal",
      "airstone",
      "soil-less"
    ],
    "content": "\n      <h3>1. Deep Water Culture (DWC) Setup</h3>\n      <ul>\n        <li><strong>Reservoir:</strong> Opaque, food-grade tub (prevents root-killing algae growth).</li>\n        <li><strong>Lid & Net Pots:</strong> Drill holes in lid; seat plastic net cups filled with clay pebbles, washed pea gravel, or charcoal chunks.</li>\n        <li><strong>Aeration:</strong> Continuously pump air through an airstone via 12V diaphragm pump or manual bellows to maintain dissolved oxygen >5 ppm.</li>\n      </ul>\n      <h3>2. Improvised Organic Hydroponic Nutrients</h3>\n      <table class=\"data-table text-xs\">\n        <tr><th>Nutrient</th><th>Improvised Source</th><th>Preparation</th></tr>\n        <tr><td><strong>Nitrogen (N)</strong></td><td>Diluted Fresh Urine / Comfrey Tea</td><td>1 part clean urine to 15 parts water (contains urea & mineral salts).</td></tr>\n        <tr><td><strong>Phosphorus (P)</strong></td><td>Calcined Bone Ash</td><td>Burn animal bones white, crush to fine powder, leach with vinegar.</td></tr>\n        <tr><td><strong>Potassium (K)</strong></td><td>Hardwood Ash Leachate</td><td>Steep 1 cup wood ash in 10L water for 2 days; neutralizes pH.</td></tr>\n        <tr><td><strong>Calcium/Magnesium</strong></td><td>Crushed Eggshells & Epsom Salt</td><td>Dissolve eggshells in vinegar for Calcium Acetate.</td></tr>\n      </table>\n    "
  },
  {
    "id": "food-adv-02",
    "domain": "Food Production",
    "title": "Aquaponics: Bell Siphons & Bacterial Nitrogen Cycling",
    "critical_level": "HIGH",
    "tags": [
      "aquaponics",
      "bell siphon",
      "nitrogen cycle",
      "tilapia",
      "grow bed",
      "symbiosis"
    ],
    "content": "\n      <h3>1. Closed-Loop Ecosystem Dynamics</h3>\n      <p>Fish produce toxic Ammonia ($NH_3$) &rarr; <em>Nitrosomonas</em> bacteria convert Ammonia to Nitrite ($NO_2^-$) &rarr; <em>Nitrobacter</em> bacteria convert Nitrite to safe Nitrate ($NO_3^-$) &rarr; Plant roots absorb Nitrate as fertilizer, returning clean water to fish.</p>\n      <div class=\"note-box\">\n        <strong>Mandatory Rule:</strong> Establishing this bacterial colony takes <strong>4 to 6 weeks</strong> of cycling with low fish density before system reaches biological equilibrium.\n      </div>\n      <h3>2. Automatic Bell Siphon Mechanics</h3>\n      <p>Allows flood-and-drain grow beds to cycle automatically without moving parts. Water fills bed, submerges roots, reaches top of inner standpipe, triggers a hydraulic vacuum siphon that rapidly empties the bed, pulling fresh atmospheric oxygen directly into root zones.</p>\n    "
  },
  {
    "id": "food-adv-03",
    "domain": "Food Production",
    "title": "Biochar Charging & Long-Term Soil Remediation",
    "critical_level": "NORMAL",
    "tags": [
      "biochar",
      "soil",
      "terra preta",
      "carbon",
      "compost tea",
      "fertility"
    ],
    "content": "\n      <h3>1. Why Raw Charcoal Kills Plants</h3>\n      <p>Fresh raw charcoal is extremely porous and dry. If placed directly into soil, it acts as a sponge, soaking up all moisture and nitrogen, severely stunting plant growth for 2 years.</p>\n      <h3>2. The Charging (Inoculation) Protocol</h3>\n      <ol>\n        <li>Crush lump charcoal into pea-sized (2–5mm) fragments.</li>\n        <li>Mix crushed biochar with <strong>equal parts mature active compost, compost tea, or animal manure slurry</strong>.</li>\n        <li>Keep damp and allow biological colonization for <strong>2 to 3 weeks</strong>.</li>\n        <li>Incorporate charged biochar into garden topsoil (10–20% by volume).</li>\n        <li>Biochar remains stable in soil for <strong>1,000+ years</strong> (Amazonian <em>Terra Preta</em>), permanently retaining water, beneficial mycorrhizal fungi, and cation nutrients.</li>\n      </ol>\n    "
  },
  {
    "id": "sec-01",
    "domain": "Security & Defense",
    "title": "Perimeter Security: Tripwire Alarms & Watch Rotations",
    "critical_level": "HIGH",
    "tags": [
      "security",
      "perimeter",
      "tripwires",
      "observation zone",
      "watch rotations",
      "defense"
    ],
    "content": "\n      <h3>1. Layered Defense Architecture</h3>\n      <ul>\n        <li><strong>Outer Observation Zone (20–30m out):</strong> Clear heavy brush, tall grass, and blind spots around settlement to eliminate covert approach routes.</li>\n        <li><strong>Early Warning Perimeter:</strong> Rig low-visibility tripwires (monofilament fishing line or thin brass wire, 15cm off ground) attached to clattering stone bundles, hanging tin cans with pebbles, or pull-pin percussion poppers.</li>\n        <li><strong>Funneled Challenge Point:</strong> Force all legitimate traffic into a single well-illuminated choke point with defilade protection for sentries.</li>\n      </ul>\n      <h3>2. Watch Scheduling & Sentry Protocols</h3>\n      <ul>\n        <li><strong>Rotation Rule:</strong> Stand <strong>two-person watches in 4-hour shifts</strong> maximum. Alertness drops by 60% after 4 consecutive hours of vigilance.</li>\n        <li>Establish challenge-response authentication passwords updated every 24 hours at sunset.</li>\n      </ul>\n    "
  },
  {
    "id": "sec-02",
    "domain": "Security & Defense",
    "title": "Soap Making: Wood Ash Lye & Saponification",
    "critical_level": "NORMAL",
    "tags": [
      "soap",
      "lye",
      "potassium hydroxide",
      "saponification",
      "tallow",
      "hygiene"
    ],
    "content": "\n      <h3>1. Extracting Potassium Hydroxide (Potash Lye)</h3>\n      <ol>\n        <li>Drill small drain holes in the bottom of a wooden barrel. Place clean gravel, then straw, then pack tightly with <strong>cold white hardwood ash</strong> (oak, hickory, beech).</li>\n        <li>Pour soft rainwater over ash. Collect amber leachate draining from the bottom.</li>\n        <li>Test concentration: Float a fresh raw egg or potato in the lye water. If it floats showing a dime-sized area above surface, concentration is correct. If it sinks, boil lye to concentrate.</li>\n      </ol>\n      <h3>2. Saponification with Animal Fat</h3>\n      <ol>\n        <li>Render animal fat (beef tallow, lard) by melting and filtering through cloth.</li>\n        <li>Warm fat to 45°C. Slowly pour lye water into fat (ratio approximately 1 part lye to 2.5 parts fat). <strong>Wear eye protection</strong>.</li>\n        <li>Stir continuously in one direction until the mixture \"traces\" (thickens to pudding consistency).</li>\n        <li>Pour into cloth-lined wooden molds. Allow to solidify for 48 hours. Cut into bars and cure in a dry room for <strong>4 to 6 weeks</strong> before use.</li>\n      </ol>\n    "
  },
  {
    "id": "craft-01",
    "domain": "Improvised Crafting",
    "title": "Pine Pitch Glue (Natural Epoxy Formulation)",
    "critical_level": "HIGH",
    "tags": [
      "pine pitch",
      "pitch glue",
      "natural epoxy",
      "glue",
      "adhesive",
      "resin",
      "spruce resin",
      "charcoal",
      "primitive glue",
      "crafting",
      "binding"
    ],
    "content": "\n      <div class=\"protocol-alert warning\">\n        <strong>THERMAL WARNING:</strong> Heat resin gently over embers. Boiling or overheating resin burns off volatile terpenes, making the cured glue brittle or catching fire.\n      </div>\n\n      <h3>1. Formulation & Component Ratios</h3>\n      <ul>\n        <li><strong>Pine / Spruce Resin (5 Parts):</strong> Collect hardened amber sap nodules from conifers. Provides the sticky, waterproof hydrocarbon matrix.</li>\n        <li><strong>Crushed Hardwood Charcoal (1 Part):</strong> Grind dead fire charcoal into fine black dust. Charcoal acts as a chemical binder and temper, reducing brittle fracture under shock.</li>\n        <li><strong>Fibrous Reinforcement (1 Part):</strong> Dried, finely teased plant fibers, shredded dry moss, or dried herbivore droppings (rabbit/deer). Adds internal tensile cross-linking.</li>\n      </ul>\n\n      <h3>2. Preparation & Melting Protocol</h3>\n      <ol>\n        <li>Melt the harvested resin in a concave stone, metal tin, or green wood ladle suspended over gentle coals.</li>\n        <li>Filter out large bark chunks using a small mesh of green twigs.</li>\n        <li>Gradually stir in the powdered charcoal and dry plant fibers until thoroughly blended into a viscous black paste.</li>\n      </ol>\n\n      <h3>3. Application & Reheating</h3>\n      <ul>\n        <li>Apply hot to haft arrowheads, secure knife blades into bone handles, seal birchbark canoes, or waterproof cracked containers.</li>\n        <li>Roll excess pitch onto a dry stick to create portable <em>pitch sticks</em>. Reheat over a small flame whenever emergency adhesive is required.</li>\n      </ul>\n    "
  },
  {
    "id": "craft-02",
    "domain": "Improvised Crafting",
    "title": "Plant Cordage & Natural Rope Making",
    "critical_level": "HIGH",
    "tags": [
      "cordage",
      "rope",
      "plant cordage",
      "string",
      "reverse wrap",
      "inner bark",
      "nettle",
      "yucca",
      "willow",
      "fibers",
      "lashing",
      "twine"
    ],
    "content": "\n      <h3>1. Harvesting High-Tensile Plant Fibers</h3>\n      <ul>\n        <li><strong>Bast Fibers (Inner Bark):</strong> Strip the fibrous inner cambium layer from willow, cedar, basswood, elm, or linden trees.</li>\n        <li><strong>Stalk Fibers:</strong> Harvest mature stalks of stinging nettle, dogbane, milkweed, hemp, or fireweed. Crush dried stalks gently and peel long outer fibrous ribbons.</li>\n        <li><strong>Leaf Fibers:</strong> Scrape flesh from tough succulent leaves such as yucca, agave, or cattail leaves.</li>\n      </ul>\n\n      <h3>2. Processing & Retting</h3>\n      <p>Soak woody fibers in water for several days (retting) or scrape gently with a dull stone to remove non-fibrous epidermal pith. Allow fibers to dry completely, then lightly dampen with water before twisting for maximum flexibility.</p>\n\n      <h3>3. The Reverse Wrap Method (2-Ply Cordage)</h3>\n      <ol>\n        <li>Take a bundle of fibers and fold it unevenly (one strand 1/3 longer than the other to prevent splice points from aligning).</li>\n        <li>Hold the twist point between your left thumb and index finger.</li>\n        <li>Twist the top strand tightly <strong>away from you (clockwise)</strong> until it kinks.</li>\n        <li>Roll the twisted top strand <strong>over the bottom strand towards you (counter-clockwise)</strong>, swapping positions.</li>\n        <li>Repeat continuously: Twist top strand away &rarr; wrap over towards you.</li>\n      </ol>\n\n      <h3>4. Splicing New Fibers</h3>\n      <p>When a strand runs down to 5cm, lay 2–3 new fiber strands alongside it with ends overlapping by 3cm. Continue the reverse wrap; the friction locks the new fibers seamlessly without bulky knots.</p>\n    "
  },
  {
    "id": "craft-03",
    "domain": "Improvised Crafting",
    "title": "Improvised Floating Needle Compass",
    "critical_level": "HIGH",
    "tags": [
      "improvised compass",
      "needle compass",
      "floating needle",
      "magnetize",
      "compass",
      "direction",
      "navigation",
      "magnetic north",
      "lost"
    ],
    "content": "\n      <h3>1. Needle Magnetization</h3>\n      <ul>\n        <li><strong>Stroke Method:</strong> Take a small steel sewing needle, safety pin, straightened paperclip, or razor blade.</li>\n        <li><strong>With a Magnet:</strong> Stroke the needle in <strong>one direction only</strong> (from eye to point) 30 to 50 times against a magnet or speaker coil. Do NOT rub back and forth.</li>\n        <li><strong>Without a Magnet:</strong> Stroke the needle continuously 50–100 times in one direction across pure silk, fleece, or through human hair to align magnetic domains via triboelectric alignment and the ambient geomagnetic field.</li>\n      </ul>\n\n      <h3>2. Water Suspension Assembly</h3>\n      <ol>\n        <li>Find a wind-sheltered pool of still water: a small puddle, puddle in a rock, plastic bottle base, or leaf bowl.</li>\n        <li>Place a small, flat dry leaf, wood shaving, piece of bark, or thin disk of wine cork gently onto the water surface.</li>\n        <li>Carefully balance the magnetized needle horizontally on top of the floating leaf carrier.</li>\n      </ol>\n\n      <h3>3. Reading & Verifying Orientation</h3>\n      <ul>\n        <li>The needle will slowly rotate and settle pointing along the local <strong>Magnetic North-South axis</strong>.</li>\n        <li>Verify which end is North by checking against the morning sun (rises in the East), evening sunset (West), or solar shadow stick.</li>\n      </ul>\n    "
  },
  {
    "id": "craft-04",
    "domain": "Improvised Crafting",
    "title": "Snow Blindness Goggles & UV Eye Protection",
    "critical_level": "HIGH",
    "tags": [
      "snow blindness",
      "goggles",
      "uv protection",
      "eye protection",
      "glare",
      "slit goggles",
      "photokeratitis",
      "sun glare",
      "sunglasses"
    ],
    "content": "\n      <div class=\"protocol-alert warning\">\n        <strong>PHOTOKERATITIS HAZARD:</strong> Ultraviolet reflection from snow (85%+ albedo), water, or white desert sand burns corneal cells within 2 hours, producing severe blindness and gritty pain.\n      </div>\n\n      <h3>1. Fabrication Materials</h3>\n      <p>Use a 15cm &times; 4cm strip of curved birch bark, lightweight wood, bone, heavy leather, thick cardboard, or double-layered duct tape folded against itself.</p>\n\n      <h3>2. Slit Geometry & Sizing</h3>\n      <ol>\n        <li>Contour the backing strip to fit snugly over the bridge of your nose and cheekbones.</li>\n        <li>Mark pupil positions directly in front of each eye.</li>\n        <li>Cut an extremely narrow horizontal slit: <strong>1mm to 2mm wide &times; 25mm to 30mm long</strong> over each eye.</li>\n        <li>Pierce small holes at both ends and tie with cordage or leather thongs around the back of your head.</li>\n      </ol>\n\n      <h3>3. Optical Performance</h3>\n      <ul>\n        <li>The pinhole/slit effect restricts incoming peripheral solar and ultraviolet radiation by <strong>over 90%</strong> while preserving clear horizontal field of vision.</li>\n        <li>Rub black charcoal dust on the inside of the goggles and below your eyes/cheekbones to eliminate reflections and glare.</li>\n      </ul>\n    "
  },
  {
    "id": "craft-05",
    "domain": "Improvised Crafting",
    "title": "Improvised Particulate Filter (Charcoal Respirator)",
    "critical_level": "HIGH",
    "tags": [
      "particulate filter",
      "respirator",
      "charcoal mask",
      "smoke mask",
      "air filter",
      "dust mask",
      "ash filter",
      "improvised mask",
      "charcoal filter"
    ],
    "content": "\n      <div class=\"protocol-alert critical\">\n        <strong>FILTER LIMITATIONS:</strong> Improvised charcoal masks trap airborne ash, smoke particles, soot, and coarse biological aerosols. They do <strong>NOT</strong> filter carbon monoxide (CO), nerve agents, or supply oxygen in low-O2 environments.\n      </div>\n\n      <h3>1. Filter Construction</h3>\n      <ol>\n        <li><strong>Charcoal Granules:</strong> Crush cold hardwood charcoal into fine coarse granules (1mm to 2mm size — do not use fine powder which clogs air passages).</li>\n        <li><strong>Fabric Envelope:</strong> Take a clean bandana, cotton cloth, or sleeve folded into a pouch.</li>\n        <li><strong>Charcoal Layer:</strong> Spread an even <strong>1-inch (2.5cm) layer</strong> of charcoal granules inside the cloth.</li>\n        <li><strong>Dampen Cloth:</strong> Lightly moisten the outer cloth with clean water to capture fine electrostatic dust particles without restricting breathing.</li>\n      </ol>\n\n      <h3>2. Fitting & Seal</h3>\n      <ul>\n        <li>Fit the respirator tightly over both the nose and mouth.</li>\n        <li>Tie upper straps firmly over the crown of the head and lower straps around the nape of the neck to prevent unfiltered air bypass around the edges.</li>\n        <li>Replace or wash and re-charcoal the filter every 4 to 6 hours during dense particulate exposure.</li>\n      </ul>\n    "
  },
  {
    "id": "prep-01",
    "domain": "Emergency Preparedness",
    "title": "The Bug-Out Bag: 72-Hour Evacuation Kit (BOB)",
    "critical_level": "CRITICAL",
    "tags": [
      "bug out bag",
      "72 hour kit",
      "emergency kit",
      "evacuation",
      "bob",
      "go bag",
      "preparedness",
      "survival kit",
      "ifak",
      "disaster kit",
      "checklist"
    ],
    "content": "\n      <div class=\"protocol-alert critical\">\n        <strong>WEIGHT RULE:</strong> A loaded evacuation pack must never exceed <strong>20% of your body weight</strong> (e.g., max 16 kg for an 80 kg individual). Place the heaviest items centered and close to your spine.\n      </div>\n\n      <h3>Priority 1: Water & Hydration</h3>\n      <ul>\n        <li><strong>Stainless Steel Bottle (1–2L):</strong> Single-walled steel allows direct boiling over fire for emergency sterilization.</li>\n        <li><strong>Sawyer Mini Micro-Filter:</strong> Rated to 0.1 microns, filters up to 100,000 gallons of water without replacement cartridges.</li>\n        <li><strong>Chemical Purification:</strong> Strip of Chlorine Dioxide tablets (effective against Cryptosporidium and viruses).</li>\n      </ul>\n\n      <h3>Priority 2: Shelter & Firecraft</h3>\n      <ul>\n        <li><strong>Tarp:</strong> 3m &times; 3m heavy-duty ripstop nylon/silnylon tarp with reinforced tie-out loops.</li>\n        <li><strong>Cordage:</strong> 30 meters of genuine 7-strand 550 military paracord.</li>\n        <li><strong>Thermal Protection:</strong> Heavy-duty mylar survival bivvy/space blanket (reflects 90% body heat).</li>\n        <li><strong>Ignition:</strong> Ferrocerium rod (5/16\" or 1/2\"), stormproof matches, 2 Bic butane lighters, and 10 cotton balls soaked in petroleum jelly stored in a waterproof film canister.</li>\n      </ul>\n\n      <h3>Priority 3: Individual First Aid Kit (IFAK)</h3>\n      <ul>\n        <li><strong>CAT Gen-7 Tourniquet:</strong> Rapid single-handed arterial hemorrhage control.</li>\n        <li><strong>Pressure Dressing:</strong> 6-inch Israeli emergency bandage.</li>\n        <li><strong>Hemostatic / Compressed Gauze:</strong> 2 rolls for aggressive wound cavity packing.</li>\n        <li><strong>Meds:</strong> Ibuprofen, broad-spectrum oral antibiotics, antihistamines (diphenhydramine), rehydration salts, moleskin blister tape.</li>\n      </ul>\n\n      <h3>Priority 4: Nutrition (72-Hour Sustenance)</h3>\n      <ul>\n        <li>High-calorie, zero-preparation, non-perishable foods: Pemmican, high-calorie peanut butter squeeze pouches, SOS 3,600 kcal emergency food ration bars, and cured jerky.</li>\n        <li>Minimum baseline: <strong>2,500 kcal per day</strong> during heavy physical evacuation terrain.</li>\n      </ul>\n\n      <h3>Priority 5: Tools, Lighting & Navigation</h3>\n      <ul>\n        <li><strong>Knife:</strong> Full-tang high-carbon fixed-blade knife (4–5 inch blade) for batoning firewood and processing materials.</li>\n        <li><strong>Multitool:</strong> Quality tool with pliers, wire cutters, saw blade, and awl.</li>\n        <li><strong>Lighting:</strong> High-efficiency LED headlamp with extra lithium batteries (or rechargeable with mini solar panel).</li>\n        <li><strong>Navigation:</strong> Laminated 1:24,000 topographic maps of your evacuation corridor, magnetic baseplate compass, permanent marker, duct tape (5m rolled flat).</li>\n      </ul>\n\n      <h3>Priority 6: Clothing Layering (\"Cotton Kills\")</h3>\n      <ul>\n        <li><strong>Base Layer:</strong> 100% Merino wool long-sleeve top and bottoms (retains thermal insulation even when saturated).</li>\n        <li><strong>Socks:</strong> 3 extra pairs of heavy-cushion Merino wool hiking socks.</li>\n        <li><strong>Footwear:</strong> Broken-in, waterproof, ankle-support hiking boots.</li>\n        <li><strong>Outerwear:</strong> Waterproof/breathable hooded rain jacket and windproof pants.</li>\n      </ul>\n    "
  }
];
