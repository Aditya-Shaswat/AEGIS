/**
 * AEGIS Hybrid AI Engine (Offline NLP + Online LLM RAG)
 * 
 * 1. Offline Mode: Local NLP tokenization, TF-IDF / keyword-frequency scoring,
 *    and structured template synthesis referencing top articles.
 * 2. Online Mode: If user supplies an API key (Gemini / OpenAI), constructs
 *    a ground-truth RAG prompt using top retrieved articles and calls the LLM.
 */

class AegisChatEngine {
  constructor() {
    this.apiKey = localStorage.getItem('aegis_llm_key') || '';
    this.provider = localStorage.getItem('aegis_llm_provider') || 'gemini'; // 'gemini' | 'openai'
    this.modelName = localStorage.getItem('aegis_llm_model') || 'gemini-2.5-flash';
    
    // Common stop words for local tokenizer
    this.stopWords = new Set([
      'a','about','above','after','again','against','all','am','an','and','any','are','aren\'t',
      'as','at','be','because','been','before','being','below','between','both','but','by','can',
      'can\'t','cannot','could','couldn\'t','did','didn\'t','do','does','doesn\'t','doing','don\'t',
      'down','during','each','few','for','from','further','had','hadn\'t','has','hasn\'t','have',
      'haven\'t','having','he','he\'d','he\'ll','he\'s','her','here','here\'s','hers','herself',
      'him','himself','his','how','how\'s','i','i\'d','i\'ll','i\'m','i\'ve','if','in','into',
      'is','isn\'t','it','it\'s','its','itself','let\'s','me','more','most','mustn\'t','my',
      'myself','no','nor','not','of','off','on','once','only','or','other','ought','our','ours',
      'ourselves','out','over','own','same','shan\'t','she','she\'d','she\'ll','she\'s','should',
      'shouldn\'t','so','some','such','than','that','that\'s','the','their','theirs','them',
      'themselves','then','there','there\'s','these','they','they\'d','they\'ll','they\'re',
      'they\'ve','this','those','through','to','too','under','until','up','very','was','wasn\'t',
      'we','we\'d','we\'ll','we\'re','we\'ve','were','weren\'t','what','what\'s','when',
      'when\'s','where','where\'s','which','while','who','who\'s','whom','why','why\'s','with',
      'won\'t','would','wouldn\'t','you','you\'d','you\'ll','you\'re','you\'ve','your','yours',
      'yourself','yourselves','tell','make','build','how','need','want','help'
    ]);
  }

  setApiKey(key, provider = 'gemini', model = 'gemini-2.5-flash') {
    this.apiKey = (key || '').trim();
    this.provider = provider;
    this.modelName = model;
    localStorage.setItem('aegis_llm_key', this.apiKey);
    localStorage.setItem('aegis_llm_provider', this.provider);
    localStorage.setItem('aegis_llm_model', this.modelName);
  }

  getApiKey() {
    return this.apiKey;
  }

  getProvider() {
    return this.provider;
  }

  isOnline() {
    if (window.AegisBridge && typeof window.AegisBridge.isOnline === 'function') {
      return window.AegisBridge.isOnline();
    }
    return navigator.onLine;
  }

  getMode() {
    if (this.apiKey && this.isOnline()) {
      return 'ONLINE_RAG';
    }
    return 'OFFLINE_NLP';
  }

  /**
   * Tokenize and normalize query text
   */
  tokenize(text) {
    if (!text) return [];
    return text
      .toLowerCase()
      .replace(/[^a-z0-9\s]/g, ' ')
      .split(/\s+/)
      .filter(w => w.length > 1 && !this.stopWords.has(w));
  }

  /**
   * Local Search & Scoring Engine over AEGIS_KB with Stemming & Topic Boosts
   */
  searchLocal(queryText, limit = 3) {
    const kb = window.AEGIS_KB || [];
    if (!kb.length) return [];

    const rawTokens = this.tokenize(queryText);
    const lowerQuery = (queryText || '').toLowerCase();

    // Stemming
    const stems = new Set();
    rawTokens.forEach(t => {
      stems.add(t);
      if (t.endsWith('ies') && t.length > 4) stems.add(t.slice(0, -3) + 'y');
      if (t.endsWith('es') && t.length > 3) stems.add(t.slice(0, -2));
      if (t.endsWith('s') && !t.endsWith('ss') && t.length > 2) stems.add(t.slice(0, -1));
      if (t.endsWith('ing') && t.length > 4) { stems.add(t.slice(0, -3)); stems.add(t.slice(0, -3) + 'e'); }
      if (t.endsWith('ed') && t.length > 3) { stems.add(t.slice(0, -2)); stems.add(t.slice(0, -1)); }
    });
    const searchStems = Array.from(stems);

    const scored = kb.map(article => {
      let score = 0;
      const lowerTitle = (article.title || '').toLowerCase();
      const lowerContent = (article.content || '').toLowerCase();
      const tags = (article.tags || []).map(t => t.toLowerCase());
      const lowerDomain = (article.domain || '').toLowerCase();

      // Topic Intent Boosts
      if (/(brick|bricks|adobe|rammed earth|mortar|masonry|cob)/i.test(lowerQuery)) {
        if (article.id === 'eng-struct-02') score += 180;
        if (article.id === 'eng-struct-01') score += 90;
      }
      if (/(fire|spark|flame|ember|kindling|tinder|bow drill|friction fire)/i.test(lowerQuery)) {
        if (article.id === 'surv-crit-01') score += 180;
      }
      if (/(water|purif|drink|boil|filter|desalin|well)/i.test(lowerQuery)) {
        if (article.id === 'water-crit-01') score += 170;
      }
      if (/(bleed|wound|tourniquet|hemorrhage)/i.test(lowerQuery)) {
        if (article.id === 'med-crit-01') score += 180;
      }
      if (/(cpr|chok|airway|heimlich)/i.test(lowerQuery)) {
        if (article.id === 'med-crit-02') score += 180;
      }
      if (/(shelter|debris hut|lean-to)/i.test(lowerQuery)) {
        if (article.id === 'surv-crit-02') score += 180;
      }
      if (/(pitch|pine pitch|glue|epoxy|adhesive|resin|spruce resin|pitch stick)/i.test(lowerQuery)) {
        if (article.id === 'craft-01') score += 180;
      }
      if (/(cordage|rope|plant cordage|reverse wrap|inner bark|nettle|yucca|willow|lashing|twine)/i.test(lowerQuery)) {
        if (article.id === 'craft-02') score += 180;
      }
      if (/(improvised compass|needle compass|floating needle|magnetize|needle|floating leaf)/i.test(lowerQuery)) {
        if (article.id === 'craft-03') score += 180;
      }
      if (/(snow blindness|goggles|slit goggles|eye protection|glare|photokeratitis|sunglasses)/i.test(lowerQuery)) {
        if (article.id === 'craft-04') score += 180;
      }
      if (/(particulate filter|charcoal mask|smoke mask|respirator|dust mask|ash filter|air filter|improvised mask)/i.test(lowerQuery)) {
        if (article.id === 'craft-05') score += 180;
      }
      if (/(bug out bag|bugout|72 hour kit|72-hour|bob|evacuation kit|emergency kit|go bag|ifak|preparedness|disaster kit)/i.test(lowerQuery)) {
        if (article.id === 'prep-01') score += 180;
      }

      searchStems.forEach(stem => {
        if (tags.includes(stem)) score += 35;
        else if (tags.some(t => t.includes(stem) || stem.includes(t))) score += 20;

        if (lowerTitle.includes(stem)) score += 30;
        if (lowerDomain.includes(stem)) score += 10;

        try {
          const count = (lowerContent.match(new RegExp(stem, 'g')) || []).length;
          score += Math.min(count * 2, 14);
        } catch (e) {}
      });

      if (score > 15) {
        if (article.critical_level === 'CRITICAL') score += 4;
        else if (article.critical_level === 'HIGH') score += 2;
      }

      return { article, score };
    });

    scored.sort((a, b) => b.score - a.score);
    return scored.filter(s => s.score > 0).slice(0, limit).map(s => s.article);
  }

  /**
   * Main Query Interface (dispatches to Offline NLP or Online RAG)
   */
  async query(userMessage) {
    const mode = this.getMode();
    const relevantArticles = this.searchLocal(userMessage, 3);

    if (mode === 'ONLINE_RAG' && this.apiKey) {
      try {
        const response = await this.callLLM(userMessage, relevantArticles);
        return {
          source: 'ONLINE_LLM_RAG',
          provider: this.provider,
          model: this.modelName,
          text: response,
          citations: relevantArticles
        };
      } catch (err) {
        console.warn('Online LLM call failed, falling back to Offline NLP:', err);
        // Fallback to offline NLP
        const offlineReply = this.generateOfflineResponse(userMessage, relevantArticles);
        return {
          source: 'OFFLINE_NLP_FALLBACK',
          text: offlineReply,
          citations: relevantArticles,
          errorNotice: 'Network/API unavailable. Generated via AEGIS Offline Survival Core.'
        };
      }
    }

    // Default: 100% Offline NLP
    const offlineReply = this.generateOfflineResponse(userMessage, relevantArticles);
    return {
      source: 'OFFLINE_NLP',
      text: offlineReply,
      citations: relevantArticles
    };
  }

  /**
   * Offline NLP Conversational Synthesizer
   */
  generateOfflineResponse(userMessage, articles) {
    if (!articles || articles.length === 0) {
      return `**AEGIS OFFLINE PROTOCOL // NO EXACT MATCH**\n\nI analyzed the offline survival database but found no specific guide directly matching your query. \n\n**Suggested Actions:**\n- Verify spelling or try broader terms (e.g. *water, bleeding, shelter, fire, electricity, radio*).\n- Browse the **Knowledge Domains** menu to explore structured protocols.`;
    }

    const primary = articles[0];
    const cleanContent = primary.content
      .replace(/<div class="protocol-alert[^>]*>([\s\S]*?)<\/div>/gi, '⚠️ **$1**\n\n')
      .replace(/<div class="note-box">([\s\S]*?)<\/div>/gi, '💡 *$1*\n\n')
      .replace(/<h3>(.*?)<\/h3>/gi, '\n### $1\n')
      .replace(/<li><strong>(.*?)<\/strong>:(.*?)<\/li>/gi, '- **$1**: $2\n')
      .replace(/<li>(.*?)<\/li>/gi, '- $1\n')
      .replace(/<[^>]+>/g, '')
      .replace(/&gt;/g, '>')
      .replace(/&lt;/g, '<')
      .replace(/&times;/g, '×')
      .trim();

    let response = `**AEGIS TACTICAL PROTOCOL: ${primary.title}**\n`;
    response += `*Domain: ${primary.domain} | Priority: ${primary.critical_level}*\n\n`;
    response += cleanContent.slice(0, 1100);

    if (cleanContent.length > 1100) {
      response += `...\n\n*(Complete protocol available in Field Reader)*`;
    }

    if (articles.length > 1) {
      response += `\n\n**Related Field Protocols:**\n`;
      articles.slice(1).forEach(art => {
        response += `- **${art.title}** (${art.domain})\n`;
      });
    }

    return response;
  }

  /**
   * Online LLM RAG Call (Gemini or OpenAI)
   */
  async callLLM(userMessage, articles) {
    const contextText = articles.map((a, i) => 
      `[Source ${i + 1}: ${a.title} (${a.domain} - Priority: ${a.critical_level})]\nTags: ${a.tags.join(', ')}\nContent: ` + 
      a.content.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim()
    ).join('\n\n');

    const systemInstruction = `You are AEGIS, an austere survival, engineering, and civilization recovery intelligence. 
Respond concisely, with authoritative practical instructions, exact proportions, formulas, and safety rules.
Ground your response primarily in the provided AEGIS Knowledge Base context. If you extrapolate, clearly separate facts from inferences.
Always prioritize human life safety, trauma containment, water purity, and structural integrity.`;

    if (this.provider === 'gemini') {
      const url = `https://generativelanguage.googleapis.com/v1beta/models/${this.modelName}:generateContent?key=${this.apiKey}`;
      const payload = {
        contents: [
          {
            role: 'user',
            parts: [
              {
                text: `${systemInstruction}\n\nAUTHORITATIVE OFFLINE GROUND TRUTH CONTEXT:\n${contextText}\n\nUSER FIELD INQUIRY:\n${userMessage}`
              }
            ]
          }
        ],
        generationConfig: {
          temperature: 0.2,
          maxOutputTokens: 800
        }
      };

      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (!res.ok) {
        const errText = await res.text();
        throw new Error(`Gemini API Error (${res.status}): ${errText}`);
      }

      const data = await res.json();
      const reply = data.candidates?.[0]?.content?.parts?.[0]?.text;
      if (!reply) throw new Error('Empty response from Gemini API');
      return reply;
    } else {
      // OpenAI Compatible
      const url = 'https://api.openai.com/v1/chat/completions';
      const payload = {
        model: 'gpt-4o-mini',
        messages: [
          { role: 'system', content: systemInstruction + '\n\nGROUND TRUTH CONTEXT:\n' + contextText },
          { role: 'user', content: userMessage }
        ],
        temperature: 0.2,
        max_tokens: 800
      };

      const res = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.apiKey}`
        },
        body: JSON.stringify(payload)
      });

      if (!res.ok) {
        const errText = await res.text();
        throw new Error(`OpenAI API Error (${res.status}): ${errText}`);
      }

      const data = await res.json();
      const reply = data.choices?.[0]?.message?.content;
      if (!reply) throw new Error('Empty response from OpenAI');
      return reply;
    }
  }
}

window.AegisChat = new AegisChatEngine();
